/**
 * Expand translation job (language) row and show files info
 *
 * @param clickedRow
 */
const expandRow = (clickedRow) => {
    const expandIcon = clickedRow.querySelector(EXPAND_ICON_SELECTOR);
    const expandableRow = getNextElement(clickedRow, EXPANDABLE_ROW_SELECTOR);
    const expandableContent = expandableRow.querySelector(EXPANDABLE_CONTENT_SELECTOR);

    // if you are collapsing the previously expanded row then collapse and exit
    if (expandableContent.classList.contains(EXPANDED_CONTENT)) {
        hideContent(expandableContent, expandIcon);
        return;
    }

    const expandedContent = table.querySelector(`.${EXPANDED_CONTENT}`);
    if (expandedContent) {
        const expandedRow = expandedContent.closest(EXPANDABLE_ROW_SELECTOR);
        const mainRow = getPrevElement(expandedRow, ROW);
        const expandedIcon = mainRow.querySelector(EXPAND_ICON_SELECTOR);
        hideContent(expandedContent, expandedIcon);
    }

    showContent(expandableContent, expandIcon);
};

/**
 * Show content
 *
 * @param content
 * @param icon
 */
const showContent = (content, icon) => {
    icon.icon = ARROW_DOWN_ICON;
    $(content).slideDown(ANIMATION_SPEED);
    content.classList.add(EXPANDED_CONTENT);
};

/**
 * Hide content
 *
 * @param content
 * @param icon
 */
const hideContent = (content, icon) => {
    icon.icon = ARROW_RIGHT_ICON;
    $(content).slideUp(ANIMATION_SPEED);
    content.classList.remove(EXPANDED_CONTENT);
};