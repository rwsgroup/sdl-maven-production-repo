/*
 * Copyright 1997-2011 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
CQ.Translator.ImportXLIFFDialog = CQ.Ext.extend(CQ.Translator.Dialog, {
    file: null,

    constructor: function(config) {
        var path = config.path || "/libs/wcm/core/i18n";
        
        this.file = new CQ.Ext.ux.form.FileUploadField({
            fieldLabel:"XLIFF",
            name: "file",
            allowBlank:false,
            width: 290,
            height: 26
        });

        CQ.Ext.applyIf(config, {
            title:"Import XLIFF translations",
            description:"Please choose an XLIFF file containing translations.",
            closeAction:"close",
            formCfg: {
                labelWidth: 80,
                labelPad: 0,
                url: path + ".dict.xliff",
                fileUpload: true
            },
            items:[
                this.file,
                new CQ.Ext.form.Checkbox({
                    fieldLabel: "Overwrite",
                    name: "overwrite"
                }),
                new CQ.Ext.form.NumberField({
                    fieldLabel: "Tree depth",
                    name: "depth",
                    value: CQ.Translator.TreeDepth,
                    hidden: true
                }),
                CQ.Translator.Dialog.createDescription("<br/><br/>Target: " + CQ.shared.XSS.getXSSValue(path)),
                CQ.Translator.Dialog.createDescription("<br/>Note: this will create a sling:Message dictionary.")
            ]
        });
        CQ.Translator.ImportXLIFFDialog.superclass.constructor.call(this, config);
    },

    doSubmit: function() {
        return this.ajaxFormSubmit();
    }
});
CQ.Ext.reg("importxliffdialog", CQ.Translator.ImportXLIFFDialog);
