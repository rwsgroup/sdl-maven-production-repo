/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2015 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
CQ.Ext.ns("CQ.Translator.TranslationProject");

CQ.Translator.TranslationProject.DefaultInputFieldWidth = 230;
CQ.Translator.TranslationProject.getActiveTranslationProjectStore = function () {
    $.ajax(CQ.Translator.TranslationProject.ajaxGetActiveTranslationProjectsOptions);
    return CQ.Translator.TranslationProject.activeTranslationProjectStore;
};

CQ.Translator.TranslationProject.getSupportedLanguageStore = function () {
    if (CQ.Translator.TranslationProject.supportedLanguageStore == null) {
        $.ajax(CQ.Translator.TranslationProject.ajaxGetSupportedLanguagesOptions);
    }
    return CQ.Translator.TranslationProject.supportedLanguageStore;
};

CQ.Translator.TranslationProject.ajaxGetActiveTranslationProjectsOptions = {
    url: Granite.HTTP.externalize("/libs/cq/gui/components/projects/admin/translation?projects=true"),
    type: "get",
    async: false,
    success: function (data, status, request) {
        try {
            var projects = data.projects;
            var activeTranslationProjects = [];
            for (var i = 0; i < projects.length; i++) {
                if (projects[i].active) {
                    activeTranslationProjects.push([projects[i].path, projects[i].title]);
                }
            }
            CQ.Translator.TranslationProject.activeTranslationProjectStore = new CQ.Ext.data.ArrayStore({
                id: 0,
                fields: [
                    'projectPath',
                    'projectTitle'
                ],
                data: activeTranslationProjects
            });

        } catch (e) {
            alert(e);
        }
    }
};

CQ.Translator.TranslationProject.ajaxGetSupportedLanguagesOptions = {
    url: Granite.HTTP.externalize("/libs/cq/gui/components/projects/admin/translation?languages=true"),
    type: "get",
    async: false,
    success: function (data, status, request) {
        try {
            var languages = data.languages;
            var languageList = [];
            for (var i = 0; i < languages.length; i++) {
                languageList.push([languages[i].code, languages[i].display]);
            }
            languageList.sort(function(a, b){return a[1].localeCompare(b[1])});
            CQ.Translator.TranslationProject.supportedLanguageStore = new CQ.Ext.data.ArrayStore({
                id: 'langListStore',
                fields: [
                    'languageCode',
                    'displayText'
                ],
                data: languageList
            });

        } catch (e) {
            alert(e);
        }
    }
};

CQ.Translator.TranslationProject.getI18nDictStore = function (parentPath, callback) {
    var ajaxOptionsGetI18nDicts = {
        url:  Granite.HTTP.externalize("/libs/cq/i18n/translator.i18ndicts.json" + "?path=" + parentPath),
        type: "get",
        async: false,
        success: function (data, status, request) {
            try {
                var i18nDicts = data.dicts;
                var i18nDictList = [];
                if(i18nDicts.length > 0){
                    i18nDictList.push(["English (en), From dictionary keys", parentPath]);
                }
                for (var i = 0; i < i18nDicts.length; i++) {
                    var dictName = i18nDicts[i].path.substr(i18nDicts[i].path.lastIndexOf('/') + 1);
                    i18nDictList.push([i18nDicts[i].lang + ' - ' + dictName, i18nDicts[i].path]);
                }
                callback(new CQ.Ext.data.ArrayStore({
                    fields: [
                        'displayText',
                        'dictPath'
                    ],
                    data: i18nDictList
                }));

            } catch (e) {
                alert(e);
            }
        }
    };
    $.ajax(ajaxOptionsGetI18nDicts);
};

CQ.Translator.TranslationProject.checkWorkflowStatus = function (workflowInstance,handle) {
    ajaxOptions = {
        url: Granite.HTTP.externalize(workflowInstance+".json"),
        type: "get",
        async: false,
        success: function (data, status, request) {
            try {
                if(data.state == 'COMPLETED'){
                    workflowMetaDataAjaxOptions ={
                        url: Granite.HTTP.externalize(workflowInstance+'/data/metaData.json'),
                        type: "get",
                        async: false,
                        success: function (data, status, request) {
                            try {
                                if(data.translationError == 'LANGUAGE_COPY_EXISTS'){
                                    CQ.Ext.MessageBox.show({
                                        icon: CQ.Ext.MessageBox.INFO,
                                        title:'Info',
                                        msg: 'All the strings in the source dictionary are already available in the destination language.' +
                                        '\<br>Translation request was ignored.',
                                        buttons: CQ.Ext.MessageBox.OK});
                            } else if(data.translationError == 'NOTHING_TO_TRANSLATE'){
                                    CQ.Ext.MessageBox.alert('Error', 'Source dictionary is empty', null);
                                } else if (data.targetPath == undefined) {
                                    CQ.Ext.MessageBox.alert('Error', 'Failed to complete request', null);
                                } else {
                                    var targetDir = data.targetPath.substring( 0,
                                        data.targetPath.lastIndexOf( "/" ));
                                    var redirectURL = Granite.HTTP.externalize("/libs/cq/i18n/translator.html?path="
                                        + targetDir);
                                    CQ.Ext.MessageBox.show({
                                        title:'Info',
                                        msg: 'Translation project created ('
                                        + data.destinationLanguage.toUpperCase() + ')',
                                        icon: CQ.Ext.MessageBox.INFO,
                                        buttons: {
                                            yes: "Show Target Dictionary",
                                            ok: "OK"
                                        },
                                        fn: function(btn) {
                                            if (btn == "yes") {
                                                window.open(redirectURL, "_self");
                                            }
                                        }
                                    });
                                }
                            } catch (e) {
                                alert(e);
                            }
                        }
                    };
                    $.ajax(workflowMetaDataAjaxOptions);
                    clearInterval(loop);
                }

            } catch (e) {
                alert(e);
            }
        }
    };
    var loop = setInterval(function() {
        $.ajax(ajaxOptions);
    }, 2000);
};

CQ.Translator.TranslationProject.getTargetPath = function (path) {

    if((path.indexOf("/apps/") == 0)
    || (path.indexOf("/content/") == 0)){
        return path;
    }
    return path.replace(/^\/.*?\//,"/apps/");

};



