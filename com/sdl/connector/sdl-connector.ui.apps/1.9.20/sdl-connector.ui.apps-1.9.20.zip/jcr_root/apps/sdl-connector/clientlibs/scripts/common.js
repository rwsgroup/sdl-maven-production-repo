/**
 * Checks if the page is the project detail one.
 *
 * @returns {boolean}
 */
const isDetailPage = () => {
    return document.querySelector(DETAIL_PAGE);
};

/**
 * Checks if the page is the projects overview one.
 *
 * @returns {boolean}
 */
const isOverviewPage = () => {
    return document.querySelector(OVERVIEW_PAGE);
};

/**
 * Convert project path to detail page path
 * e.g.
 * /content/projects/sdl/projectFolder/projectName -> /apps/sdl/connector/detail.projectFolder.projectName.html
 *
 * @param projectPath
 */const convertProjectPathToDetailPagePath = (projectPath) => {
    const selectors = projectPath.replace(PROJECTS_PATH, '').replace(JCR_CONTENT, '').replace('/', '.');
    return DETAIL_PAGE_PATH + selectors + HTML;
};

const openWindow = (element) => {
  const path = element.getAttribute("path");
  window.open(path, "_blank");
};

/**
 * Generic function for displaying a coral dialog
 *
 * @param event
 * @param selector
 * @param yes
 */
const showDialog = (event, selector, yes) => {
  if(event){
        event.stopPropagation();
     }
    const dialog = document.querySelector(selector);
    dialog.show();

    if (yes) {
        const yesBtn = dialog.querySelector(DIALOG_YES);
        yesBtn.off(CLICK).on(CLICK, () => {
            yes();
        });
    }
};

/**
 * Generic function for displaying an error coral dialog
 *
 * @param event
 * @param errorMsg
 */
const showErrorDialog = (event, errorMsg) => {
    event.stopPropagation();
    const dialog = document.querySelector(ERROR_DIALOG);
    const errorMsgEl = dialog.querySelector(DIALOG_ERROR_MSG);
    errorMsgEl.innerText = errorMsg;
    dialog.show();
};

/**
 * Show the page loader. Add a message if you want to be shown above the loader
 *
 * @param message
 */
const showPageLoader = (message) => {
    const pageLoader = document.querySelector(PAGE_LOADER);
    const loaderMsg = pageLoader.querySelector(LOADER_MSG);
    pageLoader.hidden = false;
    loaderMsg.innerText = message;
};

/**
 * Hide the page loader
 */
const hidePageLoader = () => {
    const pageLoader = document.querySelector(PAGE_LOADER);
    const loaderMsg = pageLoader.querySelector(LOADER_MSG);
    pageLoader.hidden = true;
    loaderMsg.innerText = '';
};

/**
 * Generate UUID which will be used later for saving the project in memory
 *
 * @returns {string}
 */
const generateUuid = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

/**
 * Convert field to id e.g. sourceLanguage to source-language
 *
 * @param field
 * @returns {string}
 */
const fieldToId = (field) => {
    return field.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
};

/**
 * Get current date
 *
 * @returns {string}
 */
const getCurrentDate = () => {
    const today = new Date();

    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    const yyyy = today.getFullYear();

    return yyyy + '-' + mm + '-' + dd;
};

/**
 * Get next html element by selector
 *
 * @param startEl
 * @param selector
 */
const getNextElement = (startEl, selector) => {
    const nextElement = startEl.nextElementSibling;
    if (!nextElement) {
        return null;
    }

    const plainSelector = selector.substr(1);

    if (selector.startsWith('.') && nextElement.classList.contains(plainSelector)) {
        return nextElement;
    } else if (selector.startsWith('#') && nextElement.id === plainSelector) {
        return nextElement;
    } else {
        return getNextElement(nextElement, selector);
    }
};

/**
 * get previous html element by selector
 *
 * @param startEl
 * @param selector
 */
const getPrevElement = (startEl, selector) => {
    const prevElement = startEl.previousElementSibling;
    if (!prevElement) {
        return null;
    }

    const plainSelector = selector.substr(1);

    if (selector.startsWith('.') && prevElement.classList.contains(plainSelector)) {
        return prevElement;
    } else if (selector.startsWith('#') && prevElement.id === plainSelector) {
        return prevElement;
    } else {
        getPrevElement(prevElement, selector);
    }
};

/**
 * Always generate one fake project which will be hidden. This fake project it's a trick to keep the column sizes
 * while filtering the overview list
 *
 * @param table
 */
const createFakeRow = (table) => {
    const row = createCoralTableRow(table, `${PROJECT_ROW} ${FAKE_ROW}`);

    for (let i = 0; i < 12; i++) {
        if (i === 0) {
            const firstColumn = createCoralTableColumn(row, {}, CELL_ICON, CENTER, true, 1, '');
            createCoralIcon(firstColumn, ARROW_DOWN_ICON, 'S');
        } else {
            const column = createCoralTableColumn(row, {}, determineRowClass(i), null, false, 1, i === 3 ? 'NaN' : '');
            column.innerText = PLACEHOLDER;
        }
    }
};

/**
 * Determine correct column classes by column index. Update this when updating overview-item
 *
 * @param colIndex
 * @return {string}
 */
const determineRowClass = (colIndex) => {
    switch (colIndex) {
        case 0:
            return CELL_ICON;
        case 1:
            return CELL_TITLE;
        case 2:
            return CELL_DESCRIPTION;
        case 3:
            return CELL_STATUS;
        case 4:
            return CELL_CREATOR;
        case 5:
            return CELL_CREATED_DATE;
        case 6:
            return CELL_DUE_DATE;
        case 7:
            return CELL_SOURCE_LANGUAGE;
        case 8:
            return CELL_TARGET_LANGUAGES;
        case 9:
            return CELL_COSTS;
        case 10:
            return CELL_WORD_COUNT;
        case 11:
            return CELL_CONTROLS;
    }
};

/**
 * Create empty row dynamically e.g. while filtering
 *
 * @param table
 */
const createEmptyRow = (table) => {
    const row = table.items.add({});
    const firstColumn = createCoralTableColumn(row, {}, '', CENTER, false, 12, '');
    firstColumn.innerText = NO_ITEMS_TEXT;
};

/**
 * Create coral tag <coral-tag>
 *
 * @param value
 * @param text
 * @param closable
 * @param className
 * @returns {*}
 */
const createCoralTag = (value, text, closable, className) => {
    const tag = new Coral.Tag().set({
        label: {
            innerHTML: text
        },
        value: value,
        closable
    });

    tag.classList.add(className);

    return tag;
};

/**
 * Create coral button <button is="coral-button">
 *
 * @param root
 * @param variant
 * @param icon
 * @param iconSize
 * @param className
 * @param onClick
 * @return {*|ActiveX.IXMLDOMNode}
 */
const createCoralButton = (root, variant, icon, iconSize, className, onClick) => {
    const button = root.appendChild(new Coral.Button().set({
        variant,
        icon,
        iconSize
    }));
    button.classList.add(className);
    root.insertAdjacentHTML(BEFORE_END, '\n'); // we need new line (not br)

    if (onClick) button.on(CLICK, onClick);

    return button;
};

/**
 *  Create coral icon <coral-icon>
 *
 * @param root
 * @param icon
 * @param size
 * @param id
 * @param cssClass
 * @return {*|ActiveX.IXMLDOMNode}
 */
const createCoralIcon = (root, icon, size, id, cssClass) => {
    const element = root.appendChild(new Coral.Icon().set({
        icon,
        size
    }));

    if (id) element.id = id;
    if (cssClass) element.classList.add(cssClass);

    return element;
};

/**
 * Create coral table row <tr is="coral-table-row">
 *
 * @param table
 * @param cssClass
 * @param id
 * @param link
 * @param name
 * @param isStarted
 * @param isCostsApproved
 * @return {DataTransferItem}
 */
const createCoralTableRow = (table, cssClass, id, link, name, isStarted, isCostsApproved) => {
    const row = table.items.add({});

    row.className += ` ${ROW_NAV_CLASSES} ${cssClass}`;

    if (id) row.dataset.foundationCollectionItemId = id;
    if (id) row.dataset.graniteCollectionItemId = id;
    if (link) row.dataset.foundationCollectionNavigatorHref = link;
    if (name) row.dataset.projectName = name;

    row.dataset.projectIsStarted = isStarted;
    row.dataset.projectIsCostsApproved = isCostsApproved;

    return row;
};

/**
 * Create coral table column <td is="coral-table-cell">
 *
 * @param row
 * @param columnContent
 * @param cssClass
 * @param alignment
 * @param isColSelect
 * @param colspan
 * @param value
 * @return {*|ActiveX.IXMLDOMNode}
 */
const createCoralTableColumn = (row, columnContent, cssClass, alignment, isColSelect, colspan, value) => {
    const column = row.appendChild(new Coral.Table.Cell().set(columnContent));

    if (cssClass) {
        column.className += ` ${cssClass}`;
    }

    if (alignment) {
        column.setAttribute(ALIGNMENT, alignment);
    }

    if (isColSelect) {
        column.setAttribute(ROW_SELECT, '');
    }

    if (colspan > 1) {
        column.colSpan = colspan;
    }

    column.value = value;

    return column;
};

/**
 * Create coral field wrapper where you can add form elements
 *
 * @param rootEl
 * @return {HTMLDivElement | ActiveX.IXMLDOMNode}
 */
const createCoralFieldWrapper = (rootEl) => {
    const div = document.createElement(DIV);
    div.classList.add(FIELD_WRAPPER_CLASS);
    return rootEl.appendChild(div);
};

/**
 * Create coral form field inside a field wrapper.
 * parameters example:
 * {
 *     Id: "1",
 *     Name: "Some name",
 *     Value: "Some value", // "True"/"False" if checkbox
 *     DefaultValue: "Some default value", // placeholder if input
 *     IsRequired: false,
 *     MaximumLength: 50,
 *     Description: "Some description",
 *     Options: ["test1", "test2"] // if select
 * }
 *
 * @param fieldWrapper
 * @param parameters
 * @param cssClass
 * @param type INPUT, CHECKBOX, SELECT
 * @param onChange(field)
 * @return {Coral.Textfield|ActiveX.IXMLDOMNode}
 */
const createCoralFormField = (fieldWrapper, parameters, cssClass, type, onChange) => {
    const fieldId = type + parameters.Id;
    const labelId = LABEL + fieldId;

    createCoralLabel(fieldWrapper, labelId, parameters.Name);

    let field;
    if (type === INPUT) {
        field = fieldWrapper.appendChild(new Coral.Textfield());
        if (onChange) field.on(INPUT, () => {
            onChange(field);
        });
    }

    if (type === CHECKBOX) {
        field = fieldWrapper.appendChild(new Coral.Checkbox());
        if (onChange) field.on(CHANGE, () => {
            onChange(field);
        });
        field.checked = parameters.Value === TRUE_CAMEL;
    }

    if (type === MULTIPICKLIST) {
        field = fieldWrapper.appendChild(new Coral.Select().set({
            multiple: true
        }));
        if (onChange) field.on(CHANGE, () => {
            onChange(field);
        });
        parameters.Options.forEach((option) => {
            field.items.add({
                value: option,
                content: {
                    textContent: option
                }
            });
        });
    }

    if (type === SELECT) {
        field = fieldWrapper.appendChild(new Coral.Select());
        if (onChange) field.on(CHANGE, () => {
            onChange(field);
        });

        parameters.Options.forEach((option) => {
            field.items.add({
                value: option,
                content: {
                    textContent: option
                }
            });
        });
    }

    if (field) {
        field.id = fieldId;
        field.labelledBy = labelId;
        field.required = parameters.IsRequired;

        if (cssClass) field.classList.add(cssClass);
        if (parameters.Value) field.value = parameters.Value;
        if (parameters.DefaultValue) field.placeholder = parameters.DefaultValue;

        if (type === INPUT) {
            if (parameters.MaximumLength) createCoralCharacterCount(fieldWrapper, parameters.MaximumLength, '#' + fieldId);
        }

        if (type === SELECT && !parameters.DefaultValue && !parameters.Value) {
            field.placeholder = SELECT_PATTERN.replace('$1', parameters.Name)
        }

        if (parameters.Description) {
            createCoralIcon(fieldWrapper, INFO_ICON, 'S', fieldId + ICON, TOOLTIP_ICON);
            createCoralTooltip(fieldWrapper, TOOLTIP_INSPECT, RIGHT, '#' + fieldId + ICON, parameters.Description);
        }
    }

    return field;
};

/**
 * Create coral label element
 *
 * @param fieldWrapper
 * @param id
 * @param text
 * @return {HTMLLabelElement | ActiveX.IXMLDOMNode}
 */
const createCoralLabel = (fieldWrapper, id, text) => {
    const label = document.createElement(LABEL);
    label.classList.add(FIELD_LABEL_CLASS);
    label.id = id;
    label.innerText = text;
    return fieldWrapper.appendChild(label);
};

/**
 * Create coral character count element
 *
 * @param fieldWrapper
 * @param maxLength
 * @param target
 * @return {Coral.CharacterCount|ActiveX.IXMLDOMNode}
 */
const createCoralCharacterCount = (fieldWrapper, maxLength, target) => {
    const element = fieldWrapper.appendChild(new Coral.CharacterCount());
    element.maxLength = maxLength;
    element.setAttribute(TARGET, target);
    return element;
};

/**
 * Create coral tooltip element
 *
 * @param fieldWrapper
 * @param variant
 * @param placement
 * @param target
 * @param text
 * @return {Coral.Tooltip|ActiveX.IXMLDOMNode}
 */
const createCoralTooltip = (fieldWrapper, variant, placement, target, text) => {
    const element = fieldWrapper.appendChild(new Coral.Tooltip());
    element.variant = variant;
    element.placement = placement;
    element.setAttribute(TARGET, target);
    element.innerText = text;
    return element;
};

/**
 * Toggle buttons in the action bar of the detail page based on the project status
 *
 * @param projectStatusCode
 */
const toggleDetailActionBarBtns = (projectStatusCode) => {
    const projectIsStarted = document.querySelector(PROJECT_IS_STARTED).value === TRUE;
    const projectPagePathsPresent = document.querySelector(PROJECT_PAGE_PATH_LENGTH).value > 0;
    const projectDictPathsPresent = document.querySelector(PROJECT_DICT_PATH_LENGTH).value > 0;
    const projectIsCostsApproved = document.querySelector(PROJECT_IS_COSTS_APPROVED).value === TRUE;
    const actionBar = document.querySelector(DETAIL_ACTION_BAR);
    const projectJobsInError = document.querySelector(PROJECT_JOBS_IN_ERROR).value;
    const projectTotalJobs = document.querySelector(PROJECT_TOTAL_JOBS).value;

    const deleteProjectBtn = actionBar.querySelector(`.${DELETE_PROJECT_BTN}`);
    const approveCostsBtn = actionBar.querySelector(`.${APPROVE_COSTS_BTN}`);
    const cancelProjectBtn = actionBar.querySelector(`.${CANCEL_PROJECT_BTN}`);

    deleteProjectBtn.hidden = (projectStatusCode !== DRAFT_CODE || projectIsStarted) && projectStatusCode !== CANCELLED_CODE && projectStatusCode !== CANCELLED_CODE_SDL && projectStatusCode !== COMPLETED_CODE && projectTotalJobs !== projectJobsInError;
    approveCostsBtn.hidden = projectStatusCode !== FOR_APPROVAL_CODE || projectIsCostsApproved;
    cancelProjectBtn.hidden = projectStatusCode !== FOR_APPROVAL_CODE || projectIsCostsApproved;
};

/**
 * Toggle buttons in the job row of the detail page based on the job status
 *
 * @param jobRow
 * @param jobStatusCode
 */
const toggleJobRowBtns = (jobRow, jobStatusCode) => {
    const autoApproveTranslations = jobRow.dataset.autoApproveTranslations === TRUE;
    const acceptTranslationBtn = jobRow.querySelector(`.${ACCEPT_TRANSLATION_BTN}`);
    const rejectTranslationBtn = jobRow.querySelector(`.${REJECT_TRANSLATION_BTN}`);
    const exportXmlBtn = jobRow.querySelector(`.${EXPORT_XML_BTN}`);
    const jobWorkflowAlertBtn = jobRow.querySelector(`.${ALERT_TRANSLATION_BTN}`);
    const workflowErrorValue = jobRow.dataset.workflowError;

    acceptTranslationBtn.hidden = autoApproveTranslations || (jobStatusCode !== READY_FOR_REVIEW_CODE && jobStatusCode !== FOR_DOWNLOAD_CODE);
    rejectTranslationBtn.hidden = autoApproveTranslations || (jobStatusCode !== READY_FOR_REVIEW_CODE && jobStatusCode !== FOR_DOWNLOAD_CODE);
    exportXmlBtn.hidden = jobStatusCode === DRAFT_CODE || jobStatusCode === SUBMITTED_CODE || jobStatusCode === SCOPE_REQUESTED_CODE || jobStatusCode === COMMITTED_FOR_TRANSLATION_CODE || jobStatusCode === ERROR_CODE || jobStatusCode === UNKNOWN_CODE;
    jobWorkflowAlertBtn.hidden = workflowErrorValue === 'NO_ERROR' || workflowErrorValue === 'null';
};

/**
 * Toggle buttons in the project row as part of the overview page based on the project status
 *
 * @param projectRow
 * @param projectStatusCode
 */
const toggleProjectRowBtns = (projectRow, projectStatusCode) => {
    const projectIsStarted = projectRow.dataset.projectIsStarted === TRUE;
    const projectPagePathsPresent = projectRow.dataset.projectPagePathsLength > 0;
    const projectDictPathsPresent = projectRow.dataset.projectPagePathsLength > 0;
    const projectIsCostsApproved = projectRow.dataset.projectIsCostsApproved === TRUE;
    const deleteProjectBtn = projectRow.querySelector(`.${DELETE_PROJECT_BTN}`);
    const approveCostsBtn = projectRow.querySelector(`.${APPROVE_COSTS_BTN}`);
    const cancelProjectBtn = projectRow.querySelector(`.${CANCEL_PROJECT_BTN}`);
    const projectWorkflowAlertBtn = projectRow.querySelector(`.${ALERT_TRANSLATION_BTN}`);
    const jobsInError = projectRow.dataset.jobsInError;
    const totalJobs = projectRow.dataset.totalJobs;

    deleteProjectBtn.hidden = (projectStatusCode !== DRAFT_CODE || projectIsStarted) && projectStatusCode !== CANCELLED_CODE && projectStatusCode !== CANCELLED_CODE_SDL && projectStatusCode !== COMPLETED_CODE && totalJobs !== jobsInError;
    approveCostsBtn.hidden = projectStatusCode !== FOR_APPROVAL_CODE || projectIsCostsApproved;
    cancelProjectBtn.hidden = projectStatusCode !== FOR_APPROVAL_CODE || projectIsCostsApproved;
    projectWorkflowAlertBtn.hidden = jobsInError === "0";
};

/**
 * Print message in the wizard step
 *
 * @param step
 * @param data
 * @param loadNext
 * @param error
 */
const printWizardMsg = (step, data, loadNext, error) => {
    const panelMsg = step.querySelector(PANEL_MSG);
    const panelMsgType = panelMsg.querySelector(PANEL_MSG_TYPE);
    const panelMsgText = panelMsg.querySelector(PANEL_MSG_TEXT);

    const type = data.type;
    const field = data.field;
    const msg = data.message;

    const fieldId = field ? fieldToId(field) : '';

    if (type) {
        panelMsg.variant = type;
        panelMsgType.innerText = type;
    }
    if (msg) panelMsgText.innerText = msg;

    if (type === ERROR) {
        if (fieldId) step.querySelector(`#${fieldId}`).invalid = true;
        panelMsg.hidden = false;
        if (error) error();
    } else if (type === WARNING) {
        panelMsg.hidden = false;
    } else {
        wizardView.next();
        panelMsg.hidden = true;
        if (loadNext) loadNext();
    }
};

/**
 * Hide the wizard message if type
 *
 * @param step
 * @param type
 */
const hideWizardMsg = (step, type) => {
    const panelMsg = step.querySelector(PANEL_MSG);
    if (panelMsg.variant === type) panelMsg.hidden = true;
};