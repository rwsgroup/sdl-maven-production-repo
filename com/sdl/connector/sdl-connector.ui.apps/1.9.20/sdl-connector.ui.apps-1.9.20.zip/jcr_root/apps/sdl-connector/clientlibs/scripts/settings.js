let prefixProjectTitleEl;
let preselectCloudConfigEl;
let customParametersEl;
let preselectTargetPagePropEl;
let preselectTargetStorageEl;

/**
 * Load the settings from jcr
 */
const loadSettings = () => {
    $.get(PROVIDE_SETTINGS).done((data) => {
        settings = data;

        const settingsDialog = document.querySelector(SETTINGS_DIALOG);

        prefixProjectTitleEl = settingsDialog.querySelector(PREFIX_PROJECT_TITLE);
        preselectCloudConfigEl = settingsDialog.querySelector(PRESELECT_CLOUD_CONFIG);
        customParametersEl = settingsDialog.querySelector(CUSTOM_PARAMETERS);
        preselectTargetPagePropEl = settingsDialog.querySelector(PRESELECT_TARGET_PAGE_PROP);
        preselectTargetStorageEl = settingsDialog.querySelector(PRESELECT_TARGET_STORAGE);

        prefixProjectTitleEl.checked = settings.projectTitlePrefix;
        preselectCloudConfigEl.checked = settings.configPreselection;
        customParametersEl.checked = settings.customParameters;
        preselectTargetPagePropEl.checked = settings.targetPreselectionPageProp;
        preselectTargetStorageEl.checked = settings.targetPreselectionStorage;

    });
};

/**
 * Settings dialog is open
 *
 * @param event
 */
const openSettings = (event) => {
    loadSettings();
    showDialog(event, SETTINGS_DIALOG);
};

/**
 * Save the settings to jcr
 *
 * @param event
 */
const saveSettings = (event) => {
    const settingsDialog = event.target.closest(SETTINGS_DIALOG);

    const newSettings = {};
    newSettings.projectTitlePrefix = prefixProjectTitleEl.checked;
    newSettings.configPreselection = preselectCloudConfigEl.checked;
    newSettings.customParameters = customParametersEl.checked;
    newSettings.targetPreselectionPageProp = preselectTargetPagePropEl.checked;
    newSettings.targetPreselectionStorage = preselectTargetStorageEl.checked;

    $.post(SAVE_SETTINGS, {
        settingsJson: JSON.stringify(newSettings)
    }).done(() => {
        settings = newSettings;
    }).fail(() => {
        showErrorDialog(event, UNABLE_TO_SAVE_SETTINGS);
    });

    settingsDialog.hide();
};