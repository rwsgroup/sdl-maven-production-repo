/**
 * Refresh button clicked on the Overview page
 */
const refreshOverview = () => {
    disableRefreshBtn(true);

    getProjects((projects) => {
        updateProjectRows(projects);
    });
};

/**
 * Refresh only one overview item
 *
 * @param projectPath
 */
const refreshOverviewItem = (projectPath) => {
    disableRefreshBtn(true);
    getProject(projectPath, (project) => {
        const projectRow = document.querySelector(TABLE).querySelector(`${ROW}[${DATA_PROJECT_NAME}="${project.projectName}"]`);
        if (!projectRow) {
            enableRefreshBtn(true);
            return;
        }

        updateProjectRow(project, projectRow);
    });
};

/**
 * Refresh button clicked on the Detail page
 *
 * @param forceRefresh
 */
const refreshDetail = (forceRefresh) => {
    disableRefreshBtn(true);

    const projectPath = document.querySelector(PROJECT_PATH).value;
    if (forceRefresh) forceRefreshStatus(projectPath);
    getProject(projectPath, (project) => {
        updateJobRows(project.jobs, projectPath);
        updateProjectInfo(project);
    });
};

/**
 * Update a single project row
 *
 * @param project
 * @param projectRow
 * @param invalidProject
 */
const updateProjectRow = (project, projectRow, invalidProject) => {
    let statusCode = -1;

    if (project) {
        statusCode = project.calculatedStatus.code;
        const statusText = project.calculatedStatus.status;

        if (!project.active) {
            setProjectAsInvalid(projectRow, project);
        }

        if (!isValidStatus(statusCode)) return;

        projectRow.dataset.projectIsStarted = project.started;
        projectRow.dataset.projectIsCostsApproved = project.costsApproved;
        if (project.sdlProjectId) projectRow.dataset.sdlProjectId = project.sdlProjectId;

        updateStatus(statusCode, statusText, projectRow, false);
        updateCosts(project, projectRow);
        updateWordCount(project, projectRow);
    } else {
        if (invalidProject) invalidProject();
    }

    toggleProjectRowBtns(projectRow, statusCode);
    removeStatusHighlight();
};

/**
 * Update project rows
 *
 * @param projects
 */
const updateProjectRows = (projects) => {
    const projectRows = document.querySelector(TABLE).querySelectorAll(ROW);

    projectRows.forEach((projectRow) => {
        if (isInvalidRow(projectRow)) {
            return;
        }

        const projectPath = projectRow.dataset.foundationCollectionItemId;
        forceRefreshStatus(projectPath);

        const projectRowName = projectRow.dataset.projectName;
        const validProject = projects.find(project => project.projectName === projectRowName);

        updateProjectRow(validProject, projectRow, () => {
            getProject(projectPath, (project) => {
                setProjectAsInvalid(projectRow, project);
            });
        });
    });
};

/**
 * Update jobs rows in the detail page including the file rows
 *
 * @param jobs
 * @param projectPath
 */
const updateJobRows = (jobs, projectPath) => {
    const jobRows = document.querySelector(TABLE).querySelectorAll(JOB_ROW);
    let shouldReloadTable = false;

    jobRows.forEach((jobRow) => {
        const jobRowTarget = jobRow.dataset.targetLanguage;
        const validJob = jobs.find(job => job.targetLanguage === jobRowTarget);
        if (!validJob) {
            return;
        }

        //Update workflow error information in data attribute by row
        jobRow.dataset.workflorError = validJob.workflowOperationError;
        const jobStatusCode = validJob.calculatedStatus.code;
        const jobStatusText = validJob.calculatedStatus.status;
        const currentNumberOfFiles = parseInt(jobRow.querySelector(CELL_NUMBER_OF_FILES).value);
        if (currentNumberOfFiles !== validJob.files.length) {
            shouldReloadTable = true;
        }
        updateStatus(jobStatusCode, jobStatusText, jobRow, false);

        toggleJobRowBtns(jobRow, jobStatusCode);

        // Job Status Progress Bar Update
        const jobProgressBar = jobRow.querySelector(JOB_PROGRESS);
        jobProgressBar.value = validJob.progress;

        // Update Files per job
        validJob.files.forEach((file) => {
            const fileRow = document.querySelector(`${FILE_ROW}[${DATA_FILE_ID}='${file.id}']`);
            if (!fileRow) return;

            const fileStatusCode = file.calculatedStatus.code;
            const fileStatusText = file.calculatedStatus.status;
            updateStatus(fileStatusCode, fileStatusText, fileRow, false);
        });
    });

    if (shouldReloadTable) {
        setTimeout(() => {
            reloadDetailTable(projectPath);
        }, 3000);
    }
};

/**
 * Update project info block in the detail page
 *
 * @param project
 */
const updateProjectInfo = (project) => {
    const projectInfo = document.querySelector(PROJECT_INFO);

    const statusCode = project.calculatedStatus.code;
    const statusText = project.calculatedStatus.status;

    const projectIsStartedHidden = document.querySelector(PROJECT_IS_STARTED);
    const projectIsStartedCheck = projectInfo.querySelector(PROJECT_IS_STARTED_CHECK);
    const projectIsCostsApprovedHidden = document.querySelector(PROJECT_IS_COSTS_APPROVED);
    const sdlProjectIdHidden = projectInfo.querySelector(SDL_PROJECT_ID);
    const numberOfFilesEl = projectInfo.querySelector(NUMBER_OF_FILES);
    const projectDescription = document.querySelector(PROJECT_DESCRIPTION);
    const projectConfig = document.querySelector(PROJECT_CONFIG);
    const projectDueDate = document.querySelector(PROJECT_DUE_DATE);
    const projectCreateLanguageCopy = document.querySelector(PROJECT_CREATE_LANGUAGE_COPY);
    const projectAutoApproveTranslation = document.querySelector(PROJECT_AUTO_APPROVE_TRANSLATIONS);
    const projectAutoPromoteLaunches = document.querySelector(PROJECT_AUTO_PROMOTE_LAUNCHES);
    const projectDeleteLaunchPromotion = document.querySelector(PROJECT_DELETE_LAUNCH_PROMOTION);
    const projectCustomParamsList = document.querySelector(PROJECT_CUSTOM_PARAMS_LIST);
    const infoListPagePaths = document.querySelector(PROJECT_INFO_LIST_PAGE_PATHS);
    const projectInfoTitle = document.querySelector(PROJECT_INFO_TITLE);

    projectInfoTitle.innerText = project.projectTitle;
    infoListPagePaths.innerHTML = '';
    if (project.pagePaths.length > 0) {
        project.pagePaths.forEach(pagePath => {
            //Creating list item
            const listItem = document.createElement(LI);
            listItem.innerText = pagePath;
            infoListPagePaths.appendChild(listItem);

        });
    }

    if (project.dictPaths.length > 0) {
        project.dictPaths.forEach(dicPath => {
            //Creating list item
            const listItem = document.createElement(LI);
            listItem.innerText = dicPath;
            infoListPagePaths.appendChild(listItem);
        });
    }

    projectDescription.innerText = project.description;
    projectConfig.innerText = project.configDisplayName;
    projectDueDate.innerText = project.dueDateDisplay;
    projectCreateLanguageCopy.innerText = project.createLanguageCopy ? 'Create/Update language copy' : 'Overwrite language master';
    projectAutoApproveTranslation.innerText = project.autoApproveTranslations ? '√' : 'X';
    projectAutoPromoteLaunches.innerText = project.autoPromoteLaunches ? '√' : 'X';
    projectDeleteLaunchPromotion.innerText = project.deleteLaunchPromotion ? '√' : 'X';

    projectCustomParamsList.innerHTML = '';
    if (project.customParameterMap && Object.keys(project.customParameterMap).length > 0) {
        Object.keys(project.customParameterMap).forEach(key => {
            //Creating line
            const infoLine = document.createElement(DIV);
            infoLine.classList.add(PROJECT_INFO_LINE);

            //Creating key (label field)
            const infoKey = document.createElement(DIV);
            infoKey.classList.add(PROJECT_INFO_KEY);
            infoKey.innerText = project.customParameterMap[key].name;

            //Creating value (field value
            const infoValue = document.createElement(DIV);
            infoValue.classList.add(PROJECT_INFO_VALUE);
            let value = project.customParameterMap[key].value;
            if (value === TRUE_CAMEL || value === FALSE_CAMEL) {
                value = value === TRUE_CAMEL ? '√' : 'X';
            }
            infoValue.innerText = value;

            // Adding the line to the custom param list
            infoLine.appendChild(infoKey);
            infoLine.appendChild(infoValue);
            projectCustomParamsList.appendChild(infoLine);
        });
    }

    projectIsStartedHidden.value = project.started;
    projectIsStartedCheck.innerText = project.started ? '√' : 'X';
    projectIsCostsApprovedHidden.value = project.costsApproved;
    sdlProjectIdHidden.value = project.sdlProjectId;
    numberOfFilesEl.innerText = project.jobs.reduce((sum, job) => {
        return sum + job.files.length;
    }, 0);

    updateStatus(statusCode, statusText, projectInfo, true);
    updateCosts(project, projectInfo);
    updateWordCount(project, projectInfo);

    toggleDetailActionBarBtns(statusCode);

    removeStatusHighlight();
};

/**
 * Return a filtered list of rows by status on the overview and detail page
 *
 * @return {{}[]}
 */
const filterRowsByStatus = () => {
    const rows = Array.from(document.querySelector(TABLE).querySelectorAll(ROW));

    return rows.filter((row) => {
        if (isInvalidRow(row)) {
            return;
        }

        const status = row.querySelector(CALCULATED_STATUS);
        return status && isValidStatus(status.value)
    });
};

/**
 * Validate if the status is correct for refresh process.
 *
 * @param status
 * @returns {boolean}
 */
const isValidStatus = (status) => {
    const intStatus = parseInt(status);
    return !isNaN(intStatus) &&
        intStatus !== UNKNOWN_CODE &&
        intStatus !== COMPLETED_CODE &&
        intStatus !== CANCELLED_CODE &&
        intStatus !== CANCELLED_CODE_SDL &&
        intStatus !== ERROR_CODE;
};

/**
 * Check if the row is a invalid row. Invalid row is the fake-row, no-items-row and is-lazy-loaded row.
 *
 * @param projectRow
 * @return {boolean}
 */
const isInvalidRow = (projectRow) => {
    return projectRow.classList.contains(FAKE_ROW) || projectRow.classList.contains(NO_ITEMS_ROW) || projectRow.classList.contains(LAZY_LOADED_ROW);
};

/**
 * Disable or enable overview refresh button based on the valid project statuses visible on the page
 */
const toggleOverviewRefreshBtn = () => {
    if (filterRowsByStatus().length === 0) {
        disableRefreshBtn(false);
    } else {
        enableRefreshBtn(false);
    }
};

/**
 * Disable or enable detail refresh button based on the valid project status visible on the page
 */
const toggleDetailRefreshBtn = () => {
    const projectInfo = document.querySelector(PROJECT_INFO);
    const status = projectInfo.querySelector(CALCULATED_STATUS);

    if (!isValidStatus(status.value) && filterRowsByStatus().length === 0) {
        disableRefreshBtn(false);
    } else {
        enableRefreshBtn(false);
    }
};

/**
 * Enable the refresh button
 *
 * @param stopRotate
 */
const enableRefreshBtn = (stopRotate) => {
    const refreshButton = document.querySelector(REFRESH_BUTTON);
    if (stopRotate) refreshButton.classList.remove(ROTATE);
    refreshButton.disabled = false;
};

/**
 * Disable the refresh button
 *
 * @param startRotate
 */
const disableRefreshBtn = (startRotate) => {
    const refreshButton = document.querySelector(REFRESH_BUTTON);
    if (startRotate) refreshButton.classList.add(ROTATE);
    refreshButton.disabled = true;
};

/**
 * Remove the green highlight from the status
 */
const removeStatusHighlight = () => {
    setTimeout(() => {
        const greenCells = document.querySelectorAll(`.${BG_GREEN}`);
        greenCells.forEach((greenCell) => {
            greenCell.classList.remove(BG_GREEN);
        });
        enableRefreshBtn(true);
        if (isDetailPage()) toggleDetailRefreshBtn();
        if (isOverviewPage()) toggleOverviewRefreshBtn();
    }, 3000);
};

/**
 * Update status (project status, job status and file status)
 *
 * @param statusCode
 * @param statusText
 * @param htmlBlock
 * @param isInput
 */
const updateStatus = (statusCode, statusText, htmlBlock, isInput) => {
    const statusValueEl = htmlBlock.querySelector(CALCULATED_STATUS);
    let statusParent = statusValueEl;
    let statusTextEl = statusValueEl;
    if (isInput) {
        statusParent = statusValueEl.parentElement;
        statusTextEl = statusValueEl.nextElementSibling;
    }
    if (isValidStatus(statusCode)) statusParent.classList.add(BG_GREEN);
    statusTextEl.innerText = statusText;
    if (isOverviewPage() && parseInt(statusValueEl.value) !== statusCode) {
        setFilterFromCache(false);
    }
    statusValueEl.value = statusCode;
};

/**
 * Update project costs
 *
 * @param project
 * @param htmlBlock
 */
const updateCosts = (project, htmlBlock) => {
    if (project.costs) {
        const costs = htmlBlock.querySelector(PROJECT_COST);
        costs.value = project.costs;
        costs.innerText = project.currencyCosts;
    }
};

/**
 * Update project word count
 *
 * @param project
 * @param htmlBlock
 */
const updateWordCount = (project, htmlBlock) => {
    if (project.wordCount) {
        const wordCount = htmlBlock.querySelector(PROJECT_WORD_COUNT);
        wordCount.value = project.wordCount;
        wordCount.innerText = project.wordCount;
    }
};

/**
 * Set project as invalid and add the correct status: Cancelled or Completed
 *
 * @param projectRow
 * @param project
 */
const setProjectAsInvalid = (projectRow, project) => {
    const statusCode = project.calculatedStatus.code;
    const statusText = project.calculatedStatus.status;

    projectRow.classList.add(statusText.toLowerCase());
    projectRow.projectIsStarted = project.started;
    projectRow.projectIsCostsApproved = project.costsApproved;
    updateStatus(statusCode, statusText, projectRow, false);

    toggleProjectRowBtns(projectRow, statusCode);
    removeStatusHighlight();
};