<%--
  ADOBE CONFIDENTIAL

  Copyright 2015 Adobe Systems Incorporated
  All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and may be covered by U.S. and Foreign Patents,
  patents in process, and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.

--%>
<%@page session="false" import="com.adobe.granite.ui.components.Config,
                                com.adobe.granite.workflow.WorkflowException,
                                com.adobe.granite.workflow.WorkflowSession,
                                com.adobe.granite.workflow.model.WorkflowModel,
                                javax.jcr.Node" %>
<%@ page import="javax.jcr.NodeIterator" %>
<%@ page import="javax.jcr.Session" %>
<%@ page import="javax.jcr.query.Query" %>
<%@ page import="javax.jcr.query.QueryManager" %>
<%@ page import="javax.jcr.query.QueryResult" %>
<%@ page import="java.util.HashSet" %>
<%@ page import="java.util.Set" %>
<%@ page import="org.apache.commons.lang3.StringUtils" %>
<%
%>
<%@include file="/libs/granite/ui/global.jsp" %>
<%
    Session session = currentNode.getSession();
    String targetLanguage = request.getParameter("targetLanguage");
    QueryManager qm = session.getWorkspace().getQueryManager();
    QueryResult queryResult;
    if(StringUtils.isEmpty(targetLanguage)) {
        queryResult = qm.createQuery("//element(*, mix:language)[@jcr:language] order by jcr:path",
                Query.XPATH).execute();
    } else{
        queryResult = qm.createQuery("//element(*, mix:language)" +
                        "[@jcr:language=" + "\"" + targetLanguage + "\"] order by jcr:path",
                Query.XPATH).execute();
    }
    NodeIterator nodes = queryResult.getNodes();
%>
<ul class="i18n-paths-list">
<%
    Set<String> i18nPaths = new HashSet<String>();
    while (nodes.hasNext()) {
        Node node = nodes.nextNode();
        if (node.hasNode("..")) {
            String parentPath = node.getParent().getPath();
            if(i18nPaths.add(parentPath)) {
%>
    <li class="coral-SelectList-item coral-SelectList-item--option"
        data-value="<%= xssAPI.encodeForHTMLAttr(parentPath) %>">
        <%= xssAPI.encodeForHTML(parentPath)%>
    </li>
<%
            }
        }
    }
%>
</ul>
