/*
 * Copyright 1997-2011 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */
CQ.Translator.TranslationsDialog = CQ.Ext.extend(CQ.Translator.Dialog, {

    constructor: function(config) {
        CQ.Ext.applyIf(config, {
            title: "Edit string",
            height: 500,
            resizable: true,
            //modal: false,
            languages: [],
            formCfg: {
                labelWidth: 80,
                labelPad: 0,
                defaults: {
                    xtype: "textarea",
                    height: 45,
                    anchor: "95%"
                }
            },
            items:[{
                    ref: "../stringField",
                    fieldLabel: "String"
                },{
                    ref: "../commentField",
                    fieldLabel: "Comment"
                },{
                    ref: "../editCheckbox",
                    xtype: "checkbox",
                    height: 25,
                    boxLabel: "Modify string or comment (creates copy)",
                    checked: false,
                    handler: function(chbox, checked) {
                        this.enableStringEdit(checked);
                    },
                    scope: this
                }
            ]
        });
        
        CQ.Ext.each(config.languages, function(lang) {
            config.items.push({
                name: lang,
                fieldLabel: lang.toUpperCase()
            });
        });
        
        CQ.Translator.TranslationsDialog.superclass.constructor.call(this, config);
    },

    save: function() {
        // plain add or create a copy of rec because original string/comment changed
        var isAdd = !this.rec || this.editCheckbox.getValue();
        
        var rec = isAdd ? new this.store.recordType({ key: '' }) : this.rec;
        
        rec.beginEdit();
        rec.set("string", this.stringField.getValue());
        rec.set("comment", this.commentField.getValue());
        this.form.items.each(function(f) {
            if (f != this.editCheckbox && f != this.stringField && f != this.commentField) {
                rec.set(f.name, f.getValue());
            }
        }, this);
        rec.endEdit();
        
        if (isAdd) {
            this.store.insert(0, rec);
        }
        this.hide();
    },
    
    addTranslations: function() {
        this.rec = null;
        
        this.setTitle("Add string");
        
        this.editCheckbox.setValue(false);
        this.editCheckbox.setDisabled(true);
        this.enableStringEdit(true);

        this.form.items.each(function(f) {
            f.setValue("");
        }, this);
        
        this.show();
    },
    
    enableStringEdit: function(enable) {
        if (!enable && this.rec) {
            this.stringField.setValue(this.rec.get("string"));
            this.commentField.setValue(this.rec.get("comment"));
        }
        
        this.stringField.setReadOnly(!enable);
        this.commentField.setReadOnly(!enable);
    },
    
    editTranslations: function(rec) {
        this.rec = rec;
        
        this.setTitle("Edit string");
        
        this.editCheckbox.setValue(false);
        this.editCheckbox.setDisabled(false);
        this.enableStringEdit(false);
        
        this.form.items.each(function(f) {
            if (f != this.editCheckbox && f != this.stringField && f != this.commentField) {
                f.setValue(rec.get(f.name));
            }
        }, this);
        
        this.show();
    }
});
CQ.Ext.reg("translationsdialog", CQ.Translator.TranslationsDialog);
