use(function () {
    var raw = properties.get("target_languages");
    if (!raw) {
        return { languageDisplayList: "" };
    }

    // normalize raw -> jsArray
    var jsArray = [];

    // 1) native JS array
    if (Array.isArray(raw)) {
        jsArray = raw;
    } else {
        // 2) Java array (has numeric .length)
        if (raw.length !== undefined && typeof raw !== "string") {
            for (var i = 0; i < raw.length; i++) {
                jsArray.push(raw[i]);
            }
        }
        // 3) java.util.List with get/size
        else if (typeof raw.get === "function" && typeof raw.size === "function") {
            for (var j = 0; j < raw.size(); j++) {
                jsArray.push(raw.get(j));
            }
        }
        // 4) Iterable/Iterator (has iterator())
        else if (typeof raw.iterator === "function") {
            var it = raw.iterator();
            while (it.hasNext()) {
                jsArray.push(it.next());
            }
        }
        // 5) fallback: try to coerce by for..in (cheap try)
        else {
            for (var k in raw) {
                if (raw.hasOwnProperty(k)) jsArray.push(raw[k]);
            }
        }
    }

    // now map -> extract languageDisplay safely
    var displays = [];
    for (var m = 0; m < jsArray.length; m++) {
        var item = jsArray[m];
        var val = "";

        // if it's a Sling ValueMap or Java Map: use get()
        if (item && typeof item.get === "function") {
            val = item.get("languageDisplay") || "";
        }
        // if it's a plain JS object
        else if (item && item.languageDisplay !== undefined) {
            val = item.languageDisplay || "";
        }
        // fallback to toString
        else if (item !== null && item !== undefined) {
            val = String(item);
        }

        if (val) displays.push(val);
    }

    return {
        languageDisplayList: displays.join(", ")
    };
});
