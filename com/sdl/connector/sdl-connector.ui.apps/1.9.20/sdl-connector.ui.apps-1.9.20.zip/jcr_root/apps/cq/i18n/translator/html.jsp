<%--
  Copyright 1997-2011 Day Management AG
  Barfuesserplatz 6, 4001 Basel, Switzerland
  All Rights Reserved.

  This software is the confidential and proprietary information of
  Day Management AG, ("Confidential Information"). You shall not
  disclose such Confidential Information and shall use it only in
  accordance with the terms of the license agreement you entered into
  with Day.

--%><%@ page session="false" %><%
%><%@ page import="java.util.Iterator,
                   com.day.cq.commons.JS,
                   org.apache.sling.commons.json.io.JSONStringer" %><%
%><%@ include file="/libs/foundation/global.jsp" %><%

    final String basePath = request.getContextPath() + "/libs/cq/i18n/translator/";
    
    String path = request.getParameter("path");
    if (path == null) path = "/libs/wcm/core/i18n";
%>
<html>
<head><%
    String trackingPage = new JSONStringer()
            .object()
            .key("type").value("collection")
            .key("hierarchy").value("classic:tools")
            .key("name").value("translator")
            .endObject()
            .toString();
    %><meta name="foundation.tracking.page" content="<%= xssAPI.encodeForHTMLAttr(trackingPage) %>"><%
    Resource globalHead = resourceResolver.getResource("/mnt/overlay/granite/ui/content/globalhead");
    if (globalHead != null) {
        for (Iterator<Resource> it = globalHead.listChildren(); it.hasNext();) {
            %><sling:include resource="<%= it.next() %>" /><%
        }
    }
    %><title>AEM Translator</title>
    
    <cq:includeClientLib css="cq.widgets" />
    <link rel="stylesheet" type="text/css" href="<%= basePath %>js/ext/ux/fileuploadfield.css" />
    <link rel="stylesheet" type="text/css" href="<%= basePath %>style.css" />

    <cq:includeClientLib js="cq.widgets" />
    <script type="text/javascript" src="<%= basePath %>js/ext/ux/BufferView.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/ext/ux/FileUploadField.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/Dialog.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/ImportXLIFFDialog.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/TranslationsDialog.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/TranslationProject.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/NewTranslationProjectDialog.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/ExistingTranslationProjectDialog.js"></script>
    <script type="text/javascript" src="<%= basePath %>js/translator.js"></script>
    
</head>
<body>
    <script>
<%
    Session session = resourceResolver.adaptTo(Session.class);
    if (session.propertyExists("/etc/languages/languages")) {
        Property p = session.getProperty("/etc/languages/languages");
        if (p.isMultiple()) {
            final Value[] values = p.getValues();
            String[] languages = new String[values.length];
            for (int i = 0; i < values.length; i++) {
                languages[i] = values[i].getString();
            }
%>        CQ.Translator.languages = <%= JS.array(languages) %>;<%
        }
    }
    Node i18nNode = session.nodeExists("/etc/i18n") ? session.getNode("/etc/i18n") : null;
    if (i18nNode != null && i18nNode.hasProperty("treeDepth")) {%>
        CQ.Translator.TreeDepth = "<%=i18nNode.getProperty("treeDepth").getString()%>";<%
    }

%>
        CQ.Ext.onReady(function() {
            CQ.Translator.load("<%= xssAPI.encodeForJSString(path) %>");
        })
    </script><%

        Resource globalFooter = resourceResolver.getResource("/mnt/overlay/granite/ui/content/globalfooter");
        if (globalFooter != null) {
            for (Iterator<Resource> it = globalFooter.listChildren(); it.hasNext();) {
    %><sling:include resource="<%= it.next() %>" /><%
            }
        }
%></body>
</html>
