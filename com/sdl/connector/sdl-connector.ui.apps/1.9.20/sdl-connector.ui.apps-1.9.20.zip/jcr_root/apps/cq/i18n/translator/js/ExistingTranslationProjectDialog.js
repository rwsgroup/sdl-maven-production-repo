/*
 * Copyright 1997-2011 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */


CQ.Translator.ExistingTranslationProjectDialog = CQ.Ext.extend(CQ.Translator.Dialog, {
    constructor: function (config) {
        var path = config.path || "/libs/wcm/core/i18n";

        var dlg = this;
        CQ.Ext.applyIf(config, {
            title: "Select Translation Project",
            description: "Please choose a translation project.",
            closeAction: "close",
            height: 320,
            width: 450,
            formCfg: {
                labelWidth: 150,
                labelPad: 10,
                url: Granite.HTTP.externalize("/etc/workflow/instances")
            },
            items: [

                {
                    xtype: 'combo',
                    fieldLabel: 'Translation Project',
                    hiddenName: 'projectPath',
                    allowBlank: false,
                    width: CQ.Translator.TranslationProject.DefaultInputFieldWidth,
                    forceSelection:true,
                    itemId: 'projectList',
                    typeAhead: true,
                    triggerAction: 'all',
                    lazyRender: true,
                    mode: 'local',
                    store: null,
                    valueField: 'projectPath',
                    displayField: 'projectTitle',
                    listeners: {
                        'select': function(combo, selectedProjectRecord) {
                            CQ.Ext.getCmp('projectTitle').setValue(selectedProjectRecord.get('projectTitle'));
                        }
                    }
                },

                {
                    xtype: 'combo',
                    fieldLabel: 'Source Dictionary',
                    hiddenName: 'payload',
                    allowBlank: false,
                    width: CQ.Translator.TranslationProject.DefaultInputFieldWidth,
                    forceSelection:true,
                    itemId: 'srcDict',
                    typeAhead: true,
                    triggerAction: 'all',
                    lazyRender: true,
                    mode: 'local',
                    store: null,
                    valueField: 'dictPath',
                    displayField: 'displayText',
                    listeners: {
                        afterrender: function (combo) {
                            var recordSelected = combo.getStore().getAt(0);
                            combo.setValue(recordSelected.get('dictPath'));
                        }
                    }
                },

                {
                    xtype: 'combo',
                    fieldLabel: 'Destination Language',
                    hiddenName: 'destinationLanguage',
                    allowBlank: false,
                    width: CQ.Translator.TranslationProject.DefaultInputFieldWidth,
                    forceSelection:true,
                    itemId: 'destLangList',
                    typeAhead: true,
                    triggerAction: 'all',
                    lazyRender: true,
                    mode: 'local',
                    store: null,
                    valueField: 'languageCode',
                    displayField: 'displayText'
                },

                {
                    xtype: 'checkbox',
                    name: 'checkExistingTranslations',
                    fieldLabel: 'Submit only the missing translations',
                    lazyRender: true
                },

                new CQ.Ext.form.TextField({
                    fieldLabel: "Payload Type",
                    name: "payloadType",
                    value: "JCR_PATH",
                    hidden: true
                }),
                new CQ.Ext.form.TextField({
                    fieldLabel: "Workflow Model",
                    name: "model",
                    value: "/etc/workflow/models/wcm-translation/translate-i18n-dictionary/jcr:content/model",
                    hidden: true
                }),
                new CQ.Ext.form.TextField({
                    fieldLabel: "Workflow Title",
                    name: "workflowTitle",
                    value: "Translate I18n Dictionary",
                    hidden: true
                }),
                new CQ.Ext.form.TextField({
                    fieldLabel: "Project Title",
                    id: "projectTitle",
                    name: "projectTitle",
                    value: "",
                    hidden: true
                }),
                new CQ.Ext.form.TextField({
                    name: "_charset_",
                    value: "utf-8" ,
                    hidden: true
                }),
                CQ.Translator.Dialog.createDescription("<br/><br/>Source Dictionary Path: " + CQ.shared.XSS.getXSSValue(path)),
                CQ.Translator.Dialog.createDescription("Target Dictionary Path: "
                    + CQ.shared.XSS.getXSSValue(CQ.Translator.TranslationProject.getTargetPath(path)))

            ]
        });
        CQ.Translator.ExistingTranslationProjectDialog.superclass.constructor.call(this, config);

        dlg.form.items.get('projectList').store = CQ.Translator.TranslationProject.getActiveTranslationProjectStore();
        dlg.form.items.get('destLangList').store = CQ.Translator.TranslationProject.getSupportedLanguageStore();
        CQ.Translator.TranslationProject.getI18nDictStore(path, function (store) {
            dlg.form.items.get('srcDict').store = store;
        });
    },
    handleResult: function (form, action) {
        if (action.response.status == "201") {

            CQ.Ext.MessageBox.wait("Processing dictionaries...", 'Please Wait');
            CQ.Translator.TranslationProject.checkWorkflowStatus(action.response.getResponseHeader('Location'),this);
        } else {
            CQ.Translator.Dialog.DEFAULT_ERROR_HANDLER(form, action);
        }
    },
    ajaxFormSubmit: function () {
        var dlg = this;
        this.form.getForm().submit({
            //url: this.form.url,
            timeout: 60,
            waitMsg: "submitting...",
            success: this.handleResult,
            failure: this.handleResult,
            scope: this
        });
        return true;
    },
    doSubmit: function () {
        return this.ajaxFormSubmit();
    }
});

CQ.Ext.reg("existingtranslationprojectdialog", CQ.Translator.ExistingTranslationProjectDialog);
