let settings;
let uuid = '';
let step1;
let step2;
let step3;
let wizardDialog;
let wizardView;
let table;
let isEditMode = false;

/**
 * Loads the components needed for each page overview and detail
 */
window.onload = () => {
    // settings
    loadSettings();

    // represents both, overview and detail table
    table = document.querySelector(TABLE);

    if (isDetailPage()) {
        toggleDetailRefreshBtn();
        // Load the wizard setup in detail page (used for edit mode)
        wizardLoad();
    }

    if (isOverviewPage()) {
        toggleOverviewRefreshBtn();
        createFakeRow(table);

        // Load the wizard setup in detail page (used for create project and edit mode)
        wizardLoad();

        // register clear search
        const searchField = document.querySelector(SEARCH_FIELD);
        searchField.on(SEARCH_CLEAR, () => {
            clearSearch();
        });

        // register sorting
        const headerCells = Array.from(table.querySelectorAll(HEADER_CELL));
        preSorting(headerCells);
        headerCells.forEach((headerCell) => {
            headerCell.on(CLICK, (event) => {
                // prevent default sort
                event.stopImmediatePropagation();
                resetSorting(headerCells, headerCell);
                sorting(table, headerCell);
            });
        });
    }
};

/**
 * Loads the events and components needed by the wizard.
 */
wizardLoad = () => {
    // wizard setup
    step1 = document.querySelector(STEP1);
    step2 = document.querySelector(STEP2);
    step3 = document.querySelector(STEP3);
    wizardDialog = document.querySelector(WIZARD_DIALOG);
    wizardView = document.querySelector(WIZARD_VIEW);

    wizardDialog.on(BEFORE_OPEN, (event) => {
        onWizardBeforeOpen(event);
    });

    wizardDialog.on(OPEN, (event) => {
        onWizardOpen(event);
    });

    wizardDialog.on(CLOSE, (event) => {
        onWizardClose(event);
    });
};