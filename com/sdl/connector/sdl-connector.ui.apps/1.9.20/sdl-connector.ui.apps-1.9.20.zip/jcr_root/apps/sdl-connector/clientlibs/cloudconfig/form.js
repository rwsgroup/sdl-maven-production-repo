// Constants
const CONNECTION_INFO = '/bin/v2/mantra/connection/info';
const PROJECT_OPTIONS = '/bin/v2/mantra/project/options';
const ENCRYPT = '/bin/v2/mantra/encrypt';
const TEST_CONNECTION_SUCCESS = '#test-conn-success-dialog';
const TEST_CONNECTION_FAIL = '#test-conn-fail-dialog';
const PROJECT_OPTIONS_FAIL = '#project-opt-fail-dialog';
const CORAL_WAIT = '#coral-wait';
const URL = '#url';
const USERNAME = '#username';
const PASSWORD_PLAIN = '#password-plain';
const PASSWORD = '#password';
const CLIENT_ID = '#client-id';
const CLIENT_SECRET = '#client-secret';
const PROJECT_OPTION_ID = '#project-option-id';
const PROJECT_OPTION_NAME = '#project-option-name';
const PROJECT_DURATION = '#project-duration';
const SOURCE_LANGUAGES = '#source-languages';
const TARGET_LANGUAGES = '#target-languages';
const CUSTOM_PARAMETERS = '#custom-parameters';
const TEST_CONNECTION_BTN = '#test-connection-btn';
const SELECTED_ITEM = '*[selected]';
const TIMEOUT_ADD_PAGES = '#timeout-add-pages';
const TIMEOUT_CREATE_PROJECT = '#timeout-create-project';
const TIMEOUT_START_JOBS = '#timeout-start-jobs';
const TIMEOUT_START_PROJECT = '#timeout-start-project';

// keep track of the project options with all extra parameters
let projectOptions = [];

window.onload = () => {
     if(document.querySelector("#enabled-preview").value !== "Enabled"){
           document.querySelector("#preview-type-label").hidden = true;
           document.querySelector("#preview-type").hidden = true;

           document.querySelector("#preview-url").hidden = true;
           document.querySelector("#preview-url-label").hidden = true;

           document.querySelector("#preview-cookie-label").hidden = true;
           document.querySelector("#preview-cookie").hidden = true;
       } else {
           if(document.querySelector("#preview-type").value == 'legacy') {
                 document.querySelector("#preview-url").hidden = true;
                 document.querySelector("#preview-url-label").hidden = true;

                 document.querySelector("#preview-cookie-label").hidden = true;
                 document.querySelector("#preview-cookie").hidden = true;
           }

       }
    const passwordPlain = document.querySelector(PASSWORD_PLAIN).value;
    if (passwordPlain) {
        document.querySelector(PASSWORD).value = passwordPlain;
    }
};

/**
 * Test connection with mantra
 *
 * @param testConnBtn
 */
const testConnection = (testConnBtn) => {
    const coralWait = document.querySelector(CORAL_WAIT);
    testConnBtn.disabled = true;
    coralWait.hidden = false;

    const configFullPath = document.querySelector('#config-full-path').value;
    const url = document.querySelector(URL).value;
    const username = document.querySelector(USERNAME).value;
    const password = document.querySelector(PASSWORD).value;
    const clientId = document.querySelector(CLIENT_ID).value;
    const clientSecret = document.querySelector(CLIENT_SECRET).value;
    const projectOptionId = document.querySelector(PROJECT_OPTION_ID).value;

    $.get(CONNECTION_INFO, {
        url,
        username,
        password,
        clientId,
        clientSecret,
        projectOptionId,
        configFullPath
    }).done(() => {
        document.querySelector(TEST_CONNECTION_SUCCESS).show();
    }).fail((data) => {
        document.querySelector(TEST_CONNECTION_FAIL).show();
    }).always(() => {
        testConnBtn.disabled = false;
        coralWait.hidden = true;
    });
};

/**
 * Load project options based on the credentials set
 *
 * @param selectBox
 */
const loadProjectOptions = (selectBox) => {
    selectBox.items.clear();

    const coralWait = document.querySelector(CORAL_WAIT);
    const testConnBtn = document.querySelector(TEST_CONNECTION_BTN);
    testConnBtn.disabled = true;
    coralWait.hidden = false;

    const url = document.querySelector(URL).value;
    const username = document.querySelector(USERNAME).value;
    const password = document.querySelector(PASSWORD).value;
    const clientId = document.querySelector(CLIENT_ID).value;
    const clientSecret = document.querySelector(CLIENT_SECRET).value;
    const projectOptionId = document.querySelector(PROJECT_OPTION_ID).value;

    const addPagesToProjectTimeout = document.querySelector(TIMEOUT_ADD_PAGES).value;
    const createProjectTimeout = document.querySelector(TIMEOUT_CREATE_PROJECT).value;
    const startJobsTimeout = document.querySelector(TIMEOUT_START_JOBS).value;
    const startProjectTimeout = document.querySelector(TIMEOUT_START_PROJECT).value;

    $.get(PROJECT_OPTIONS, {
        url,
        username,
        password,
        clientId,
        clientSecret,
        projectOptionId,
        addPagesToProjectTimeout,
        createProjectTimeout,
        startJobsTimeout,
        startProjectTimeout
    }).done((data) => {
        projectOptions = data;
        projectOptions.forEach((projectOption) => {
            selectBox.items.add(projectOption.selectOption);
        });
    }).fail(() => {
        document.querySelector(PROJECT_OPTIONS_FAIL).show();
    }).always(() => {
        testConnBtn.disabled = false;
        coralWait.hidden = true;
    });
};

/**
 * Update projectOptionsName, sourceLanguages and targetLanguages input hidden, so it will be properly
 * saved to the repository
 *
 * @param selectBox
 */
const onProjectOptionChange = (selectBox) => {
    const selectedItem = selectBox.querySelector(SELECTED_ITEM);
    const selectedText = selectedItem.innerText.trim();
    const selectedId = selectedItem.value;

    document.querySelector(PROJECT_OPTION_NAME).value = selectedText;

    projectOptions.forEach((projectOption) => {
        if (projectOption.id === selectedId) {
            document.querySelector(PROJECT_DURATION).value = JSON.stringify(projectOption.projectDuration);
            document.querySelector(SOURCE_LANGUAGES).value = JSON.stringify(projectOption.sourceLanguages);
            document.querySelector(TARGET_LANGUAGES).value = JSON.stringify(projectOption.targetLanguages);
            document.querySelector(CUSTOM_PARAMETERS).value = JSON.stringify(projectOption.customParameters);
        }
    });
};

const encryptPassword = () => {
    $.get(ENCRYPT, {
        toEncrypt: document.querySelector(PASSWORD_PLAIN).value
    }).done((data) => {
        document.querySelector(PASSWORD).value = data;
    });
};

const onPreviewOptionChange = (selectBox) => {
    const selectedItem = selectBox.querySelector(SELECTED_ITEM);
    const selectedText = selectedItem.innerText.trim();
    const selectedId = selectedItem.value;

    if(selectedId === 'Enabled'){
                document.querySelector("#preview-type-label").hidden = false;
                document.querySelector("#preview-type").hidden = false;
                document.querySelector("#preview-url").hidden = false;
                document.querySelector("#preview-url-label").hidden = false;
                document.querySelector("#preview-cookie-label").hidden = false;
   				document.querySelector("#preview-cookie").hidden = false;
           }
           else{
               document.querySelector("#preview-type-label").hidden = true;
               document.querySelector("#preview-type").hidden = true;
               document.querySelector("#preview-url").hidden = true;
               document.querySelector("#preview-url-label").hidden = true;
               document.querySelector("#preview-cookie-label").hidden = true;
   			   document.querySelector("#preview-cookie").hidden = true;
   			   document.querySelector("#preview-cookie").value = "";
           }
}


const onPreviewTypeChange = () => {
     if(document.querySelector("#preview-type").value == 'legacy') {
         document.querySelector("#preview-url").hidden = true;
         document.querySelector("#preview-url-label").hidden = true;

         document.querySelector("#preview-cookie-label").hidden = true;
         document.querySelector("#preview-cookie").hidden = true;
     } else {
            document.querySelector("#preview-url").hidden = false;
            document.querySelector("#preview-url-label").hidden = false;

            document.querySelector("#preview-cookie-label").hidden = false;
            document.querySelector("#preview-cookie").hidden = false;
     }
}