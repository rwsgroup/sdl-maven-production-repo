<%--
  Copyright 1997-2011 Day Management AG
  Barfuesserplatz 6, 4001 Basel, Switzerland
  All Rights Reserved.

  This software is the confidential and proprietary information of
  Day Management AG, ("Confidential Information"). You shall not
  disclose such Confidential Information and shall use it only in
  accordance with the terms of the license agreement you entered into
  with Day.

--%><%@ page session="false" %><%
%><%@ page import="java.util.*,
                   org.apache.sling.api.resource.*,
                   org.apache.sling.commons.json.io.JSONWriter" %><%!

    private String getLanguage(Resource languageNode) {
        ValueMap props = languageNode.adaptTo(ValueMap.class);
        if (props == null) {
            return null;
        }
        return props.get("jcr:language", String.class);
    }

%><%

    final List<Resource> languageNodes = new ArrayList<Resource>();
    // need to keep a list of the (few) language nodes, iter is so one-time only...
    Iterator<Resource> iter = resolver.listChildren(i18n);
    while (iter.hasNext()) {
        Resource languageNode = iter.next();
        if (getLanguage(languageNode) != null) {
            languageNodes.add(languageNode);
        }
    }
    // keep simple list of languages
    List<String> languages = new ArrayList<String>(languageNodes.size());
    for (int i=0; i < languageNodes.size(); i++) {
        languages.add(getLanguage(languageNodes.get(i)));
    }
%>
