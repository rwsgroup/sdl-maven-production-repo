(function ($, ns, channel) {
    "use strict";

    // =========================
    // Constants
    // =========================

    const CONNECTION_INFO = '/bin/v2/mantra/connection/info';
    const PROJECT_OPTIONS = '/bin/v2/mantra/project/options';
    const ENCRYPT = '/bin/v2/mantra/encrypt';

    const TEST_CONNECTION_SUCCESS = '#test-conn-success-dialog';
    const TEST_CONNECTION_FAIL = '#test-conn-fail-dialog';
    const PROJECT_OPTIONS_FAIL = '#project-opt-fail-dialog';
    const CORAL_WAIT = '#coral-wait';

    const URL = '#url';
    const USERNAME = '#username';
    const PASSWORD_PLAIN = '#password-plain';
    const PASSWORD = '#password';
    const CLIENT_ID = '#client-id';
    const CLIENT_SECRET = '#client-secret';

    const PROJECT_OPTION_ID = '#project-option-id';
    const PROJECT_OPTION_NAME = '#project-option-name';

    const PROJECT_DURATION = '#project-duration';
    const SOURCE_LANGUAGES = '#source-languages';
    const TARGET_LANGUAGES = '#target-languages';
    const CUSTOM_PARAMETERS = '#custom-parameters';

    const TEST_CONNECTION_BTN = '#test-connection-btn';
    const SELECTED_ITEM = '*[selected]';

    const TIMEOUT_ADD_PAGES = '#timeout-add-pages';
    const TIMEOUT_CREATE_PROJECT = '#timeout-create-project';
    const TIMEOUT_START_JOBS = '#timeout-start-jobs';
    const TIMEOUT_START_PROJECT = '#timeout-start-project';

    let projectOptions = [];

    // =========================
    // Page Load
    // =========================

    window.onload = () => {

        if ($( "#enabled-preview" ).val() !== "Enabled") {

            $("#preview-type-label").prop("hidden", true);
            $("#preview-type").prop("hidden", true);

            $("#preview-url").prop("hidden", true);
            $("#preview-url-label").prop("hidden", true);

            $("#preview-cookie-label").prop("hidden", true);
            $("#preview-cookie").prop("hidden", true);

        } else {

            if ($("#preview-type").val() === "legacy") {

                $("#preview-url").prop("hidden", true);
                $("#preview-url-label").prop("hidden", true);

                $("#preview-cookie-label").prop("hidden", true);
                $("#preview-cookie").prop("hidden", true);
            }
        }

        const passwordPlain = $(PASSWORD_PLAIN).val();

        if (passwordPlain) {
            $(PASSWORD).val(passwordPlain);
        }
    };

    // =========================
    // Test Connection
    // =========================

    const testConnection = (testConnBtn) => {

        const coralWait = document.querySelector(CORAL_WAIT);

        testConnBtn.disabled = true;
        coralWait.hidden = false;

        $.get(CONNECTION_INFO, {
            url: $(URL).val(),
            username: $(USERNAME).val(),
            password: $(PASSWORD).val(),
            clientId: $(CLIENT_ID).val(),
            clientSecret: $(CLIENT_SECRET).val(),
            projectOptionId: $(PROJECT_OPTION_ID).val(),
            configFullPath: $("#config-full-path").val()
        })
        .done(() => {
            document.querySelector(TEST_CONNECTION_SUCCESS).show();
        })
        .fail(() => {
            document.querySelector(TEST_CONNECTION_FAIL).show();
        })
        .always(() => {
            testConnBtn.disabled = false;
            coralWait.hidden = true;
        });
    };

    // =========================
    // Load Project Options
    // =========================

    const loadProjectOptions = (selectBox) => {

        selectBox.items.clear();

        const coralWait = document.querySelector(CORAL_WAIT);
        const testConnBtn = document.querySelector(TEST_CONNECTION_BTN);

        testConnBtn.disabled = true;
        coralWait.hidden = false;

        $.get(PROJECT_OPTIONS, {
            url: $(URL).val(),
            username: $(USERNAME).val(),
            password: $(PASSWORD).val(),
            clientId: $(CLIENT_ID).val(),
            clientSecret: $(CLIENT_SECRET).val(),
            projectOptionId: $(PROJECT_OPTION_ID).val(),
            addPagesToProjectTimeout: $(TIMEOUT_ADD_PAGES).val(),
            createProjectTimeout: $(TIMEOUT_CREATE_PROJECT).val(),
            startJobsTimeout: $(TIMEOUT_START_JOBS).val(),
            startProjectTimeout: $(TIMEOUT_START_PROJECT).val()
        })
        .done((data) => {

            projectOptions = data;

            projectOptions.forEach((projectOption) => {
                selectBox.items.add(projectOption.selectOption);
            });

        })
        .fail(() => {
            document.querySelector(PROJECT_OPTIONS_FAIL).show();
        })
        .always(() => {
            testConnBtn.disabled = false;
            coralWait.hidden = true;
        });
    };

    // =========================
    // Project Option Change
    // =========================

    const onProjectOptionChange = (selectBox) => {

        const selectedItem = selectBox.querySelector(SELECTED_ITEM);
        const selectedId = selectedItem.value;
        const selectedText = selectedItem.innerText.trim();

        $(PROJECT_OPTION_NAME).val(selectedText);

        projectOptions.forEach((projectOption) => {

            if (projectOption.id === selectedId) {

                $(PROJECT_DURATION).val(
                    JSON.stringify(projectOption.projectDuration)
                );

                $(SOURCE_LANGUAGES).val(
                    JSON.stringify(projectOption.sourceLanguages)
                );

                $(TARGET_LANGUAGES).val(
                    JSON.stringify(projectOption.targetLanguages)
                );

                $(CUSTOM_PARAMETERS).val(
                    JSON.stringify(projectOption.customParameters)
                );
            }
        });
    };

    // =========================
    // Encrypt Password
    // =========================

    const encryptPassword = () => {

        $.get(ENCRYPT, {
            toEncrypt: $(PASSWORD_PLAIN).val()
        })
        .done((data) => {
            $(PASSWORD).val(data);
        });
    };

    // =========================
    // Preview Option Change
    // =========================

    const onPreviewOptionChange = (selectBox) => {

        const selectedItem = selectBox.querySelector(SELECTED_ITEM);
        const selectedId = selectedItem.value;

        if (selectedId === "Enabled") {

            $("#preview-type-label").prop("hidden", false);
            $("#preview-type").prop("hidden", false);

            $("#preview-url").prop("hidden", false);
            $("#preview-url-label").prop("hidden", false);

            $("#preview-cookie-label").prop("hidden", false);
            $("#preview-cookie").prop("hidden", false);

        } else {

            $("#preview-type-label").prop("hidden", true);
            $("#preview-type").prop("hidden", true);

            $("#preview-url").prop("hidden", true);
            $("#preview-url-label").prop("hidden", true);

            $("#preview-cookie-label").prop("hidden", true);
            $("#preview-cookie").prop("hidden", true);
            $("#preview-cookie").val("");
        }
    };

    // =========================
    // Preview Type Change
    // =========================

    const onPreviewTypeChange = () => {

        if ($("#preview-type").val() === "legacy") {

            $("#preview-url").prop("hidden", true);
            $("#preview-url-label").prop("hidden", true);

            $("#preview-cookie-label").prop("hidden", true);
            $("#preview-cookie").prop("hidden", true);

        } else {

            $("#preview-url").prop("hidden", false);
            $("#preview-url-label").prop("hidden", false);

            $("#preview-cookie-label").prop("hidden", false);
            $("#preview-cookie").prop("hidden", false);
        }
    };

    // =========================
    // Expose methods globally if needed
    // =========================

    window.testConnection = testConnection;
    window.loadProjectOptions = loadProjectOptions;
    window.onProjectOptionChange = onProjectOptionChange;
    window.encryptPassword = encryptPassword;
    window.onPreviewOptionChange = onPreviewOptionChange;
    window.onPreviewTypeChange = onPreviewTypeChange;

}(jQuery, Granite.author, jQuery(document)));