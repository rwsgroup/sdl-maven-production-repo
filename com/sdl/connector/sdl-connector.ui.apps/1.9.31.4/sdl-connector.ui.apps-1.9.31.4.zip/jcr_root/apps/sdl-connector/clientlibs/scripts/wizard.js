// keep track of the selected paths in the first step
// e.g. selectedFiles = [{title: Test1, path: /test/path1},{title: Test2, path: /test/path2}]
let selectedFiles = [];
let selectedDicts = [];
let selectedTags = [];

let includeChildPages = false;
let projectTitle = '';
let projectDesc = '';
let cloudConfigPath = '';
let cloudConfigFullPath = '';
let dueDate = '';
let sourceLanguage = '';
let targetLanguages = [];
let createLanguageCopy = true;
let autoApproveTranslations = false;
let autoPromoteLaunches = false;
let deleteLaunchPromotion = false;
let autoConfigPreselected = false;
let titlePrefixed = false;
// e.g. customParameters = {343: {name: Test 1, value: test-1, type: input, required: true, maxLength: 50}} where 343 is ID
let customParameters = {};
let projectSetupInvalid = false;
let customParametersInvalid = false;

//EditMode
let projectPathEditMode = '';

/**
 * Change properties before the wizard is showed
 *
 * @param event
 */
const onWizardBeforeOpen = (event) => {
    //Set Title to create mode
    document.querySelector(WIZARD_TITLE).innerText = CREATE_PROJECT;

    //all related to edit
    if (isEditMode) {
        //Set Title to create mode
        document.querySelector(WIZARD_TITLE).innerText = EDIT_PROJECT;
    }
};

/**
 * When wizard is open
 *
 * @param event
 */
const onWizardOpen = (event) => {
    // for some reason this event is also fired on the child dialogs e.g. dueDate
    if (`#${event.target.id}` === WIZARD_DIALOG) {
        uuid = generateUuid();

        // trigger config select change in order to load the source and the target languages
        step2.querySelector(CLOUD_CONFIG_PATH).trigger(CHANGE);
        updateProjectSetup();

        //all related to edit
        if (isEditMode) {
            loadEditMode();
        }

        // initialize i18n
        populateI18nRoot();
    }
};

/**
 * When wizard is closed
 *
 * @param event
 */
const onWizardClose = (event) => {
    // for some reason this event is also fired on the child dialogs e.g. dueDate
    if (`#${event.target.id}` === WIZARD_DIALOG) {
        $.post(PROJECT_DELETE, {
            uuid
        }).done(() => {
            resetProjectSetup();
        });
    }
};

/**
 * Remove child pages if Include child pages checkbox is checked
 *
 * @param incChildPagesChk
 */
const includeChildPagesChkChange = (incChildPagesChk, filesView) => {
    includeChildPages = incChildPagesChk.checked;

    // clean child pages if includeChildPages is true
    if (includeChildPages && (filesView === FILES || filesView === undefined || filesView === TAGS)) {
        printWizardMsg(step1, {
            type: WARNING,
            message: HIGH_LOAD_TEXT
        });
        removeChildPaths();
    } else {
        hideWizardMsg(step1, WARNING);
    }
};

/**
 * Add selected files to translation queue. This method is executed when Add button is clicked
 */
const addFilesForTranslation = () => {
    const view = document.querySelector(ITEM_VIEW).value;
    if (view === FILES) {
        const filePicker = step1.querySelector(FILE_PICKER);
        const items = Array.from(filePicker.querySelectorAll(ROW));

        items.forEach((item) => {
            if (item.classList.contains(IS_SELECTED)) {
                const file = getSelectedFile(item);

                // deselect always
                item.selected = false;

                // if file is already selected, highlight it for a second
                if (fileAlreadySelected(file)) {
                    highlightFileTag(file);
                    return;
                }

                // if child file is selected but parent already selected, highlight the parent for a second
                if (includeChildPages && parentExistsInSelectedFiles(file)) {
                    const parent = getSelectedParent(file);
                    highlightFileTag(parent);
                    return;
                }

                selectFile(file);

                // clean child files if includeChildPages is true
                if (includeChildPages) {
                    removeChildPaths();
                }
            }
        });
    }
     if (view === TAGS) {
        const tagpicker = step1.querySelector(TAG_PICKER);
        const items = Array.from(tagpicker.querySelectorAll(ROW));

        items.forEach((item) => {
            if (item.classList.contains(IS_SELECTED)) {
                const file = getSelectedTag(item);

                // deselect always
                item.selected = false;

                // if file is already selected, highlight it for a second
                if (tagAlreadySelected(file)) {
                    highlightFileTag(file);
                    return;
                }

                // if child file is selected but parent already selected, highlight the parent for a second
                if (includeChildPages && parentExistsInSelectedTags(file)) {
                    const parent = getSelectedParent(file);
                    highlightFileTag(parent);
                    return;
                }

                selectTag(file);

                // clean child files if includeChildPages is true
                if (includeChildPages) {
                    removeChildPaths();
                }
            }
        });
    }
    else if (view === I18N) {
        const selectBox = document.querySelector(I18N_CHILD_PATHS);
        const dict = getSelectedDict(selectBox);

        if (dict.title === '' || dict.path === '') {
            return;
        }

        if (dictAlreadySelected(dict)) {
            highlightFileTag(dict);
            return;
        }

        selectDict(dict);
    }
    enableNextButtonStep1();
};

/**
 * Send step1 to the backend and validate. Go to step2 if no errors
 */
const completeStep1 = () => {
    if (settings.configPreselection) {
        showPageLoader("Loading configuration");
    }
	const selectedfilesandtags = selectedFiles.concat(selectedTags);
    $.post(PROJECT_STEP1, {
        uuid,
        selectedPaths: selectedfilesandtags.map(file => file.path),
        selectedPathsTitles: selectedfilesandtags.map(file => file.title),
        selectedDicts: selectedDicts.map(file => file.path),
        selectedDictsTitles: selectedDicts.map(file => file.title)
    }).done((data) => {
        if (settings.configPreselection) {
            setTimeout(function () {
                hidePageLoader();
                printWizardMsg(step1, data, () => {
                    loadStep2(data.defaults);
                });
            }, 2000);
        } else {
            printWizardMsg(step1, data, () => {
                loadStep2(data.defaults);
            });
        }
    }).fail(() => {
        printWizardMsg(step1, {
            type: ERROR,
            message: UNABLE_TO_UPDATE_PROJECT_SETUP
        });
    });
};

/**
 * Load step 2 and preselect some defaults
 *
 * @param defaults
 */
const loadStep2 = (defaults) => {
    if (!defaults) {
        return;
    }

    step2.querySelector(CONFIG_DEFAULT_PATH_HIDDEN).value = defaults.configPath;
    step2.querySelector(CONFIG_DEFAULT_INHERITED_HIDDEN).value = defaults.configInherited;

    if (!isEditMode) {
        prefixTitle(defaults);
        preselectConfigAndTargetLanguages(defaults);
        preselectPrevTargetLanguages();
    } else {
        updateProjectSetup();
    }
};

/**
 * Prefix the title if this setting is enabled and page contains brand, businessArea and/or division property
 *
 * @param defaults
 */
const prefixTitle = (defaults) => {
    if (defaults.titlePrefix !== null && defaults.titlePrefix !== undefined && defaults.titlePrefix !== "") {
        const titleEl = step2.querySelector(PROJECT_TITLE);
        titleEl.value = defaults.titlePrefix;
        titleEl.trigger(INPUT);
        titlePrefixed = true;
    } else if (titlePrefixed) {
        const titleEl = step2.querySelector(PROJECT_TITLE);
        titleEl.value = "";
        titlePrefixed = false;
    }
};

/**
 * Preselect the cloud config and the target languages if these settings are enabled and page contains cq:conf property
 *
 * @param defaults
 */
const preselectConfigAndTargetLanguages = (defaults) => {
    if (defaults.configPath !== null && defaults.configPath !== undefined && defaults.configPath !== "") {
        const cloudConfigSelect = step2.querySelector(CLOUD_CONFIG_PATH);
        cloudConfigSelect.value = defaults.configPath;
        cloudConfigSelect.trigger(CHANGE);

        if (settings.targetPreselectionPageProp) {
            setTimeout(() => {
                const targetLanguagesSelect = document.querySelector(TARGET_LANGUAGES);
                preselectMultiSelectValues(targetLanguagesSelect);
            }, 500);
        }

        autoConfigPreselected = true;
    } else if (autoConfigPreselected) {
        const cloudConfigSelect = step2.querySelector(CLOUD_CONFIG_PATH);
        cloudConfigSelect.value = DEFAULT_CONFIG;
        cloudConfigSelect.trigger(CHANGE);

        if (settings.targetPreselectionPageProp) {
            const targetLanguagesSelect = document.querySelector(TARGET_LANGUAGES);
            emptyMultiSelectValues(targetLanguagesSelect);
            autoConfigPreselected = false;
        }
    }
};

/**
 * Show or hide the cloud configuration icon in step 2 for inheritance cloudConfiguration
 *
 */
const showInheritanceIconCloudConf = () => {
    const cloudConfigDefaultInherited = step2.querySelector(CONFIG_DEFAULT_INHERITED_HIDDEN).value;
    const cloudConfigDefaultPath = step2.querySelector(CONFIG_DEFAULT_PATH_HIDDEN).value;
    const cloudConfigSelect = step2.querySelector(CLOUD_CONFIG_PATH).value;
    const cloudConfigIconInheritance = step2.querySelector(CLOUD_CONFIG_PATH_ICON_INHERITANCE);

    cloudConfigIconInheritance.hidden = cloudConfigDefaultPath === cloudConfigSelect && cloudConfigDefaultInherited === 'true' ? false : true;
};

/**
 * Preselect previously selected target languages if that setting is enabled and the setting "preselect target
 * languages based on the cq:conf property" is disabled.
 *
 * setTimeout is added in case this setting is enabled in combination with the cloud config preselection
 */
const preselectPrevTargetLanguages = () => {
    setTimeout(() => {
        if (settings.targetPreselectionStorage && !settings.targetPreselectionPageProp) {
            const prevTargetLanguages = localStorage.getItem(PREV_TARGET_LANGUAGES);
            if (prevTargetLanguages) {
                prevTargetLanguages.split(',').forEach((prevTargetLanguage) => {
                    const targetLanguagesSelect = document.querySelector(TARGET_LANGUAGES);
                    preselectMultiSelectValue(targetLanguagesSelect, prevTargetLanguage);
                });
            }
        }
    }, 500);
};

/**
 * Send step2 to the backend and validate. Go to step3 if no errors
 */
const completeStep2 = () => {
    const panelMsg = step3.querySelector(PANEL_MSG);
    panelMsg.hidden = true;
    $.post(PROJECT_STEP2, {
        uuid,
        includeChildPages,
        projectTitle,
        projectDesc,
        cloudConfigPath,
        cloudConfigFullPath,
        dueDate,
        sourceLanguage,
        targetLanguages,
        createLanguageCopy,
        autoApproveTranslations,
        autoPromoteLaunches,
        deleteLaunchPromotion,
        customParameters: JSON.stringify(customParameters)
    }).done((data) => {
        printWizardMsg(step2, data, () => {
            if (settings.targetPreselectionStorage && !settings.targetPreselectionPageProp) {
                localStorage.setItem(PREV_TARGET_LANGUAGES, targetLanguages.join());
            }

            loadStep3();
        });
    }).fail(() => {
        printWizardMsg(step2, {
            type: ERROR,
            message: UNABLE_TO_UPDATE_PROJECT_SETUP
        });
    });
};

/**
 * Load project summary in step3 when step2 is completed
 */
const loadStep3 = () => {
    const summary = step3.querySelector(PANEL_SUMMARY);
    summary.innerHTML = '';

    const projectDescLabel = step2.querySelector(PROJECT_DESC_LABEL).innerText.trim();
    const autoApproveTranslationsLabel = step2.querySelector(AUTO_APPROVE_TRANSLATIONS).innerText.trim();
    const autoPromoteLaunchesLabel = step2.querySelector(AUTO_PROMOTE_LAUNCHES).innerText.trim();
    const deleteLaunchPromotionLabel = step2.querySelector(DELETE_LAUNCH_PROMOTION).innerText.trim();
    const cloudConfigPathLabel = step2.querySelector(CLOUD_CONFIG_PATH_LABEL).innerText.trim();
    const cloudConfigName = step2.querySelector(CLOUD_CONFIG_PATH).querySelector(`[value="${cloudConfigPath}"]`).innerText.trim();
    const dueDateLabel = step2.querySelector(DUE_DATE_LABEL).innerText.trim();
    const sourceLanguageLabel = step2.querySelector(SOURCE_LANGUAGE_LABEL).innerText.trim();
    const sourceLanguageValueText = step2.querySelector(SOURCE_LANGUAGE).querySelector(SELECT_LIST).querySelector(`[value="${sourceLanguage}"]`).innerText.trim();
    const targetLanguagesLabel = step2.querySelector(TARGET_LANGUAGES_LABEL).innerText.trim();
    const targetLanguagesValue = getMultiSelectValuesText(step2.querySelector(TARGET_LANGUAGES));
    const translatedContentLocationLabel = step2.querySelector(TRANSLATED_CONTENT_LOCATION_LABEL).innerText.trim();
    const translatedContentLocationValue = step2.querySelector(TRANSLATED_CONTENT_LOCATION).value;
    const translatedContentLocationValueText = step2.querySelector(TRANSLATED_CONTENT_LOCATION).querySelector(SELECT_LIST).querySelector(`[value="${translatedContentLocationValue}"]`).innerText.trim();
    const incChildPagesChk = includeChildPages;

    createSummaryItem(summary, '', projectTitle, true);
    createSummaryItem(summary, projectDescLabel, projectDesc);
    createSummaryItem(summary, SELECTED_FILES_TEXT, selectedFiles.concat(selectedDicts), false, '', FILE);
    createSummaryItem(summary, SELECTED_TAGS_TEXT, selectedTags, false, '', TAG);
    createSummaryItem(summary, autoApproveTranslationsLabel, autoApproveTranslations);
    createSummaryItem(summary, autoPromoteLaunchesLabel, autoPromoteLaunches);
    createSummaryItem(summary, deleteLaunchPromotionLabel, deleteLaunchPromotion);
    createSummaryItem(summary, cloudConfigPathLabel, cloudConfigName, false, cloudConfigPath);
    createSummaryItem(summary, dueDateLabel, dueDate);
    createSummaryItem(summary, sourceLanguageLabel, sourceLanguageValueText);
    createSummaryItem(summary, targetLanguagesLabel, targetLanguagesValue);
    createSummaryItem(summary, translatedContentLocationLabel, translatedContentLocationValueText);
    createSummaryItem(summary, "include child pages", incChildPagesChk);

    if (customParameters) {
        for (let key in customParameters) {
            let summaryText = customParameters[key].value;
            if (customParameters[key].type === CHECKBOX) {
                summaryText = summaryText === TRUE_CAMEL;
            }
            createSummaryItem(summary, customParameters[key].name, summaryText);
        }
    }
};

/**
 * Get selected item from the item with class is-selected
 *
 * @param item
 * @returns {{title: string, path: string}}
 */
const getSelectedFile = (item) => {
    const title = item.querySelector(FILE_PICKER_ITEM_TITLE).innerText.trim();
    const path = item.dataset.foundationCollectionItemId;
    return {title, path};
};


const getSelectedTag = (item) => {
    const title = item.querySelector(FILE_PICKER_ITEM_TITLE).innerText.trim();
    const path = item.dataset.foundationCollectionItemId;
    return {title, path};
};

/**
 * Get selected i18n dictionary from the item with class is-selected
 *
 * @param item
 * @returns {{title: string, path: string}}
 */
const getSelectedDict = (item) => {
    const title = item.value.substr(1);
    const path = item.value;
    return {title, path};
};

/**
 * Get selected parent file from the selected child file
 *
 * @param file
 * @returns {{title: string, path: string}}
 */
const getSelectedParent = (file) => {
    return selectedFiles.find(selectedFile => file.path.startsWith(selectedFile.path));
};

/**
 * Get selected child file from the selected parent file
 *
 * @param file
 * @returns {{title: string, path: string}}
 */
const getSelectedChild = (file) => {
    return selectedFiles.find(selectedFile => selectedFile.path.startsWith(file.path));
};

/**
 * Remove all the selected child paths. Usually used when includeChildPages checkbox is checked
 */
const removeChildPaths = () => {
    selectedFiles.forEach((file) => {
        if (childHasParentInSelectedFiles(file)) {
            const child = getSelectedChild(file);
            highlightAndRemoveFileTag(child);
        }
    });
    selectedTags.forEach((file) => {
        if (childHasParentInSelectedFiles(file)) {
            const child = getSelectedChild(file);
            highlightAndRemoveFileTag(child);
        }
    });
};

/**
 * Select file for translation. File is selected when file is checked in the picker and add button clicked
 *
 * @param file
 */
const selectFile = (file) => {
    if (file) {
        selectedFiles.push(file);
        addFileTag(file);
    }

};
    const selectTag = (tag) => {
    if (tag) {
        selectedTags.push(tag);
        addFileTag(tag);
    }

};

/**
 * Select i18h dictionary for translation. Dictionary is selected when dict is selected in the dropdown and add button clicked
 *
 * @param dict
 */
const selectDict = (dict) => {
    if (dict) {
        selectedDicts.push(dict);
        addFileTag(dict);
    }
};

/**
 * Deselect file. File is deselected when X button is clicked on the file TAG located bellow the file picker
 *
 * @param file
 */
const deselectFile = (file) => {
    const selectedIndex = selectedFiles.findIndex(selectedFile => selectedFile.path === file.path);

    if (selectedIndex !== -1) {
        selectedFiles.splice(selectedIndex, 1);
        removeFileTag(file);
    }

    const selectedTagIndex = selectedTags.findIndex(selectedFile => selectedFile.path === file.path);

    if (selectedTagIndex !== -1) {
        selectedTags.splice(selectedTagIndex, 1);
        removeFileTag(file);
    }

    const selectedDict = selectedDicts.findIndex(selectedFile => selectedFile.path === file.path);

    if (selectedDict !== -1) {
        selectedDicts.splice(selectedDict, 1);
        removeFileTag(file);
    }

    const button = step1.querySelector(BUTTON_NEXT);
    button.disabled = selectedFiles.length + selectedDicts.length === 0;
};

/**
 * Get the html element by provided file path
 *
 * @param file
 * @returns {Element}
 */
const getFileTag = (file) => {
    const controlsLeft = step1.querySelector(STEP1_CONTROLS_LEFT);
    return controlsLeft.querySelector(`${CORAL_TAG}[value="${file.path}"]`);
};

/**
 * Add new file tag to the list of tags located bellow the file picker
 *
 * @param file
 */
const addFileTag = (file) => {
    const controlsLeft = step1.querySelector(STEP1_CONTROLS_LEFT);
    const pathTag = createCoralTag(file.path, file.title, true, PATH_TAG);
    controlsLeft.append(pathTag);

    // let the coral-tag be created and then attach an event to the remove button
    setTimeout(() => {
        pathTag.querySelector(TAG_REMOVE_BTN).off(CLICK).on(CLICK, () => {
            deselectFile(file);
        });
    }, 500);
};

/**
 * Remove file tag from the list of tags located bellow the file picker
 *
 * @param file
 */
const removeFileTag = (file) => {
    getFileTag(file).remove();
};

/**
 * Highlight green the file tag in the list of tags located bellow the file picker
 *
 * @param file
 */
const highlightFileTag = (file) => {
    const pathTag = getFileTag(file);
    pathTag.color = COLOR_GREEN;
    setTimeout(() => {
        pathTag.color = COLOR_GREY;
    }, 1000);
};

/**
 * Highlight red and remove the file tag in the list of tags located bellow the file picker
 *
 * @param file
 */
const highlightAndRemoveFileTag = (file) => {
    const pathTag = getFileTag(file);
    pathTag.color = COLOR_RED;
    setTimeout(() => {
        deselectFile(file);
    }, 1000);
};

/**
 * Check if parent file exists in the selected files list
 *
 * @param file
 * @returns {boolean}
 */
const parentExistsInSelectedFiles = (file) => {
    return !fileAlreadySelected(file) && selectedFiles.some(selectedFile => file.path.startsWith(selectedFile.path))
};

    const parentExistsInSelectedTags = (file) => {
    return !tagAlreadySelected(file) && selectedTags.some(selectedFile => file.path.startsWith(selectedFile.path))
};

/**
 * Check if child file has a parent in the selected files list
 *
 * @param file
 * @returns {boolean}
 */
const childHasParentInSelectedFiles = (file) => {
    return selectedFiles.some(selectedFile => selectedFile.path !== file.path && file.path.startsWith(selectedFile.path))
};

 const childHasParentInSelectedTags = (file) => {
    return selectedTags.some(selectedFile => selectedFile.path !== file.path && file.path.startsWith(selectedFile.path))
};



/**
 * Check if file already exists in the selected files list
 *
 * @param file
 * @returns {boolean}
 */
const fileAlreadySelected = (file) => {
    return selectedFiles.some(selectedFile => selectedFile.path === file.path);
};

    const tagAlreadySelected = (file) => {
    return selectedTags.some(selectedFile => selectedFile.path === file.path);
};

/**
 * Check if dict already exists in the selected dicts list
 *
 * @param dict
 * @returns {boolean}
 */
const dictAlreadySelected = (dict) => {
    return selectedDicts.some(selectedDict => selectedDict.path === dict.path);
};

/**
 * Create summary item for step3
 *
 * @param summary
 * @param name
 * @param value
 * @param isHeader
 * @param addition
 * @param type
 */
const createSummaryItem = (summary, name, value, isHeader, addition, type) => {
    const summaryItemDiv = `<div class="summary-item ${isHeader ? 'item-header' : ''}">`;
    const summaryItemKeyDiv = `<div class="summary-item-key">`;
    const summaryItemValueDiv = `<div class="summary-item-value">`;
    const endDiv = `</div>`;

    const nameFinal = name.replace('*', '').trim();

    let valueFinal = '';

    if (typeof value === BOOLEAN) {
        valueFinal = value ? '√' : 'X';
    }

    if (typeof value === STRING) {
        valueFinal = value;
    }

    if (typeof value === OBJECT) {
        const multiValueItemSpan = `<span class="${type === FILE ? 'multi-file-item' : 'multi-value-item'}">`;
        const endSpan = `</span>`;

        value.forEach((item) => {
            const itemFinal = type === FILE || type === TAG ? item.path : item;
            valueFinal += `${multiValueItemSpan}${itemFinal}${endSpan}`;
        });
    }

    if (addition) {
        valueFinal += ` (${addition})`;
    }

    if (!valueFinal) {
        valueFinal = NOT_APPLICABLE;
    }

    if (isHeader) {
        summary.insertAdjacentHTML(BEFORE_END, `${summaryItemDiv}${valueFinal}${endDiv}`);
    } else {
        summary.insertAdjacentHTML(BEFORE_END, `${summaryItemDiv}${summaryItemKeyDiv}${nameFinal}${endDiv}${summaryItemValueDiv}${valueFinal}${endDiv}${endDiv}`);
    }
};

/**
 * Update project setup but also update source and target language select boxes
 *
 * @param configSelect
 */
const onConfigChange = (configSelect) => {
    updateProjectSetup();

    const selectedItem = configSelect.querySelector(SELECTED_ITEM);
    loadLanguages(selectedItem);
    updateDueDate();

    if (settings.customParameters) {
        loadCustomParameters(selectedItem);
    }
};


function updateDueDate(){
    const cloudConfigSelect = step2.querySelector(CLOUD_CONFIG_PATH);
    var minutesString = cloudConfigSelect.querySelector(`[value="${cloudConfigPath}"]`).querySelector(".project-duration").value;
    let minutesToAdd = parseInt(minutesString, 10);
    let currentEpochMinutes = Math.floor(Date.now() / 60000); // Divide by 1000 (ms) * 60 (seconds)
    let updatedEpochMinutes = currentEpochMinutes + minutesToAdd;
    let updatedDate = new Date(updatedEpochMinutes * 60000);
    dueDate = updatedDate.toISOString().split('T')[0];
    step2.querySelector(DUE_DATE).value = dueDate;
}

/**
 * Load source and target languages in the select boxes
 *
 * @param selectedItem
 */
const loadLanguages = (selectedItem) => {
    const sourceLanguagesJson = selectedItem.querySelector(SOURCE_LANGUAGES_HIDDEN).value;
    const targetLanguagesJson = selectedItem.querySelector(TARGET_LANGUAGES_HIDDEN).value;

    // clear the source select first
    const sourceLanguageSelect = step2.querySelector(SOURCE_LANGUAGE);
    sourceLanguageSelect.items.clear();
    sourceLanguageSelect.value = '';

    // clear the target select second
    const targetLanguagesSelect = step2.querySelector(TARGET_LANGUAGES);
    targetLanguagesSelect.items.clear();
    emptyMultiSelectValues(targetLanguagesSelect);

    // if source or target languages are empty, leave the selects empty
    if (!sourceLanguagesJson || !targetLanguagesJson) {
        return;
    }

    const sourceLanguageList = JSON.parse(sourceLanguagesJson);
    const targetLanguageList = JSON.parse(targetLanguagesJson);
    const sortedSourceLanguages = sourceLanguageList.sort((a, b) => a.languageDisplay > b.languageDisplay ? 1 : -1);
    const sortedTargetLanguages = targetLanguageList.sort((a, b) => a.languageDisplay > b.languageDisplay ? 1 : -1);

    sortedSourceLanguages.forEach((languageMap) => {
        sourceLanguageSelect.items.add({
            value: languageMap.languageCode,
            content: {
                textContent: languageMap.languageDisplay
            }
        })
    });

    sortedTargetLanguages.forEach((languageMap) => {
        targetLanguagesSelect.items.add({
            value: languageMap.languageCode,
            content: {
                textContent: languageMap.languageDisplay
            }
        })
    });
};

/**
 * Load custom parameters fields
 */
const loadCustomParameters = (selectedItem) => {
    if (!isEditMode) {
        customParameters = {};
    }

    if (settings.customParameters) {
        const customParametersPlaceholder = document.querySelector(CUSTOM_PARAMETERS_PLACEHOLDER);
        customParametersPlaceholder.innerHTML = '';

        const customParametersJson = selectedItem.querySelector(CUSTOM_PARAMETERS_HIDDEN).value;
        const customParametersList = JSON.parse(customParametersJson);

        customParametersList.forEach((customParameter) => {
            let fieldWrapper;
            switch (customParameter.Control) {
                case INPUT_CODE:
                    fieldWrapper = createCoralFieldWrapper(customParametersPlaceholder);
                    if (!isEditMode) {
                        updateCustomParameters(customParameter, customParameter.Value, INPUT);
                    }
                    createCoralFormField(fieldWrapper, customParameter, CUSTOM_PARAMETER_CLASS, INPUT, (field) => {
                        updateCustomParameters(customParameter, field.value, INPUT);
                    });
                    break;
                case CHECKBOX_CODE:
                    fieldWrapper = createCoralFieldWrapper(customParametersPlaceholder);
                    if (!isEditMode) {
                        updateCustomParameters(customParameter, customParameter.Value, CHECKBOX);
                    }
                    createCoralFormField(fieldWrapper, customParameter, CUSTOM_PARAMETER_CLASS, CHECKBOX, (field) => {
                        updateCustomParameters(customParameter, field.checked ? TRUE_CAMEL : FALSE_CAMEL, CHECKBOX);
                    });
                    break;
                case MULTIPICKLIST_CODE:
                    fieldWrapper = createCoralFieldWrapper(customParametersPlaceholder);
                    if (!isEditMode) {
                        updateCustomParameters(customParameter, customParameter.Value, SELECT);
                    }
                    createCoralFormField(fieldWrapper, customParameter, CUSTOM_PARAMETER_CLASS, MULTIPICKLIST, (field) => {
                        updateCustomParameters(customParameter, field.value, SELECT);
                    });
                    break;
                case SELECT_CODE:
                    fieldWrapper = createCoralFieldWrapper(customParametersPlaceholder);
                    if (!isEditMode) {
                        updateCustomParameters(customParameter, customParameter.Value, SELECT);
                    }
                    createCoralFormField(fieldWrapper, customParameter, CUSTOM_PARAMETER_CLASS, SELECT, (field) => {
                        updateCustomParameters(customParameter, field.value, SELECT);
                    });
                    break;
            }
        });

        if (isEditMode) {
            customParametersList.forEach((customParameter) => {
                switch (customParameter.Control) {
                    case INPUT_CODE:
                        if (customParameters[customParameter.Id]) {
                            document.getElementById(INPUT + customParameter.Id).value = customParameters[customParameter.Id].value;
                        }
                        break;
                    case CHECKBOX_CODE:
                        if (customParameters[customParameter.Id]) {
                            document.getElementById(CHECKBOX + customParameter.Id).checked = customParameters[customParameter.Id].value === TRUE_CAMEL ? true : false;
                        }
                        break;
                    case MULTIPICKLIST_CODE:
                    case SELECT_CODE:
                        if (customParameters[customParameter.Id]) {
                            document.getElementById(SELECT + customParameter.Id).value = customParameters[customParameter.Id].value;
                        }
                        break;
                }
            });
        }

        customParametersPlaceholder.style.display = customParametersList.length === 0 ? NONE : BLOCK;

        validateCustomParameters();
    }
};

/**
 * Update custom parameters object
 *
 * @param customParameter
 * @param value
 * @param type INPUT, CHECKBOX, SELECT, MULTISELECT
 */
const updateCustomParameters = (customParameter, value, type) => {
    customParameters[customParameter.Id] = {
        name: customParameter.Name,
        value,
        type,
        required: customParameter.IsRequired,
        maxLength: customParameter.MaximumLength
    };

    validateCustomParameters();
};

/**
 * Validate custom parameters and toggle next button based on the validation
 */
const validateCustomParameters = () => {
    let invalidParameterFound = false;
    for (let key in customParameters) {
        const value = customParameters[key].value;
        const required = customParameters[key].required;
        const type = customParameters[key].type;
        const maxLength = customParameters[key].maxLength;

        if ((required && !value) || (type === INPUT && value.length > maxLength)) {
            invalidParameterFound = true;
        }
    }
    const button = step2.querySelector(BUTTON_NEXT);
    customParametersInvalid = invalidParameterFound;
    button.disabled = customParametersInvalid || projectSetupInvalid;
};

/**
 * Update project setup properties in step 2. Usually when wizard is open or on field change
 */
const updateProjectSetup = () => {
    projectTitle = step2.querySelector(PROJECT_TITLE).value;
    projectDesc = step2.querySelector(PROJECT_DESC).value;

    const cloudConfigSelect = step2.querySelector(CLOUD_CONFIG_PATH);
    cloudConfigPath = cloudConfigSelect.value;
    cloudConfigFullPath = cloudConfigSelect.querySelector(`[value="${cloudConfigPath}"]`).querySelector(CONFIG_FULL_PATH_HIDDEN).value;
    dueDate = step2.querySelector(DUE_DATE).value;
    sourceLanguage = step2.querySelector(SOURCE_LANGUAGE).value;
    targetLanguages = getMultiSelectValues(step2.querySelector(TARGET_LANGUAGES));

    const translatedContentLocation = step2.querySelector(TRANSLATED_CONTENT_LOCATION).value;
    createLanguageCopy = translatedContentLocation === LANGUAGE_COPY;

    autoApproveTranslations = step2.querySelector(AUTO_APPROVE_TRANSLATIONS).checked;

    autoPromoteLaunches = step2.querySelector(AUTO_PROMOTE_LAUNCHES).checked;
    step2.querySelector(DELETE_LAUNCH_PROMOTION).disabled = !autoPromoteLaunches;
    if (!autoPromoteLaunches) {
        step2.querySelector(DELETE_LAUNCH_PROMOTION).checked = false;
        deleteLaunchPromotion = false;
    }

    deleteLaunchPromotion = step2.querySelector(DELETE_LAUNCH_PROMOTION).checked;

    const button = step2.querySelector(BUTTON_NEXT);
    projectSetupInvalid = !projectTitle || projectTitle.length > 50 || projectDesc.length > 255 || !cloudConfigPath || !dueDate || !sourceLanguage || targetLanguages.length === 0 || !translatedContentLocation;
    button.disabled = customParametersInvalid || projectSetupInvalid;
    showInheritanceIconCloudConf();
};

/**
 * Reset project setup to default. Usually when wizard is closed or project is created or saved
 */
const resetProjectSetup = () => {
    // reset variables
    uuid = '';
    selectedFiles = [];
    selectedDicts = [];
    selectedTags = [];
    includeChildPages = false;
    projectTitle = '';
    projectDesc = '';
    cloudConfigPath = '';
    dueDate = getCurrentDate();
    sourceLanguage = '';
    targetLanguages = [];
    createLanguageCopy = true;
    autoApproveTranslations = true;
    autoPromoteLaunches = true;
    deleteLaunchPromotion = true;
    autoConfigPreselected = false;
    titlePrefixed = false;
    customParameters = {};
    projectSetupInvalid = false;
    customParametersInvalid = false;
    projectPathEditMode = '';

    resetWizardSteps();

    // move to step1
    // there is no function for move to particular step, so we are moving backwards twice
    wizardView.previous();
    wizardView.previous();
};

/**
 * Load the information from the project that was selected to be edited and setup all information for the wizard
 */
const loadEditMode = () => {
    getProject(projectPathEditMode, (project) => {

        selectedFiles = [];
        selectedDicts = [];
    	selectedTags = [];
        includeChildPages = project.includeChildPages;
        projectTitle = project.projectTitle;
        projectDesc = project.description;
        cloudConfigPath = project.configPath;
        dueDate = `${project.dueDate.year}-${project.dueDate.monthValue}-${project.dueDate.dayOfMonth}`;
        createLanguageCopy = project.createLanguageCopy;
        autoApproveTranslations = project.autoApproveTranslations;
        autoPromoteLaunches = project.autoPromoteLaunches;
        deleteLaunchPromotion = project.deleteLaunchPromotion;
        autoConfigPreselected = false;
        titlePrefixed = false;
        if (project.customParameterMap) {
            customParameters = project.customParameterMap;
        } else {
            customParameters = {};
        }
        projectSetupInvalid = false;
        customParametersInvalid = false;

        resetWizardSteps();

        //Add files to Step1
        project.pagePaths.forEach(function (path, index) {
            let title = '';
            if (project.pagePathsTitles.length > 0) {
                title = project.pagePathsTitles[index];
            } else {
                title = path.substring(1);
            }
            selectFile({title, path});
        });
    	project.tagPaths.forEach(function (path, index) {
            let title = '';
            if (project.tagPathsTitles.length > 0) {
                title = project.tagPathsTitles[index];
            } else {
                title = path.substring(1);
            }
            selectTag({title, path});
        });

        project.dictPaths.forEach(function (path, index) {
            const title = path.substring(1);
            selectFile({title, path});
        });

        //Add source language and target language based on configuration and information saved in the project
        const cloudConfigSelect = step2.querySelector(CLOUD_CONFIG_PATH);
        cloudConfigSelect.trigger(CHANGE);
        setTimeout(() => {
            sourceLanguage = project.sourceLanguage;
            targetLanguages = project.targetLanguages;

            const sourceLanguagesSelect = step2.querySelector(SOURCE_LANGUAGE);
            sourceLanguagesSelect.value = sourceLanguage;

            const targetLanguagesSelect = step2.querySelector(TARGET_LANGUAGES);


            targetLanguages.forEach(value => {
                preselectMultiSelectValue(targetLanguagesSelect, value);
            });

            cloudConfigSelect.disabled = true;
            sourceLanguagesSelect.disabled = true;
            targetLanguagesSelect.disabled = true;
        }, 500);

        enableNextButtonStep1();
    });
};

/**
 * Reste the information in the steps based in the information saved in the let attributes.
 */
const resetWizardSteps = () => {
    // reset step1
    step1.querySelector(STEP1_CONTROLS_LEFT).innerHTML = '';
    step1.querySelector(BUTTON_NEXT).disabled = true;
    step1.querySelector(INCLUDE_CHILD_PAGES_CHK).checked = false;
    const filePicker = step1.querySelector(FILE_PICKER);
    while (filePicker.childNodes.length > 1) {
        filePicker.removeChild(filePicker.lastChild);
    }
    const activeItem = filePicker.firstChild.querySelector(`.${IS_ACTIVE}`);
    if (activeItem) {
        activeItem.classList.remove(IS_ACTIVE);
    }
    step1.querySelector(PANEL_MSG).hidden = true;
    document.querySelector(ITEM_VIEW).value = FILES;
    toggleWizardView(document.querySelector(ITEM_VIEW));
    const rootPaths = $(I18N_ROOT_PATHS).get(0);
    rootPaths.value = null;
    populateI18nChild(rootPaths);

    // reset step2
    const projectTitleField = step2.querySelector(PROJECT_TITLE);
    const projectDescField = step2.querySelector(PROJECT_DESC);
    const projectTitleCharCount = getNextElement(projectTitleField, CHAR_COUNT);
    const projectDescCharCount = getNextElement(projectDescField, CHAR_COUNT);
    projectTitleField.value = projectTitle;
    projectDescField.value = projectDesc;
    projectTitleCharCount.innerText = 50;
    projectDescCharCount.innerText = 255;
    projectTitleField.classList.remove(IS_INVALID);
    projectDescField.classList.remove(IS_INVALID);
    projectTitleCharCount.classList.remove(IS_INVALID);
    projectDescCharCount.classList.remove(IS_INVALID);
    step2.querySelector(CLOUD_CONFIG_PATH).value = cloudConfigPath;
    step2.querySelector(CLOUD_CONFIG_PATH).disabled = false;
    step2.querySelector(DUE_DATE).value = dueDate;
    step2.querySelector(SOURCE_LANGUAGE).value = sourceLanguage;
    step2.querySelector(SOURCE_LANGUAGE).disabled = false;
    if (targetLanguages.length == 0) {
        emptyMultiSelectValues(step2.querySelector(TARGET_LANGUAGES));
    }
    step2.querySelector(TARGET_LANGUAGES).disabled = false;
    if (createLanguageCopy) {
        step2.querySelector(TRANSLATED_CONTENT_LOCATION).value = LANGUAGE_COPY;
    } else {
        step2.querySelector(TRANSLATED_CONTENT_LOCATION).value = OVERWRITE_MASTER;
    }
    step2.querySelector(AUTO_APPROVE_TRANSLATIONS).checked = autoApproveTranslations;
    step2.querySelector(AUTO_PROMOTE_LAUNCHES).checked = autoPromoteLaunches;
    step2.querySelector(DELETE_LAUNCH_PROMOTION).checked = deleteLaunchPromotion;
    step2.querySelector(BUTTON_NEXT).disabled = true;
    step2.querySelector(PANEL_MSG).hidden = true;
    step2.querySelector(CUSTOM_PARAMETERS_PLACEHOLDER).innerHTML = '';
    step2.querySelector(CLOUD_CONFIG_PATH_ICON_INHERITANCE).hidden = true;

    // reset step3
    step3.querySelector(PANEL_SUMMARY).innerHTML = '';
    step3.querySelector(PANEL_MSG).hidden = true;
};

/**
 * Preselect multi select values dynamically
 *
 * @param element
 */
const preselectMultiSelectValues = (element) => {
    const items = element.querySelectorAll(SELECT_LIST_ITEM);

    items.forEach((item) => {
        item.selected = true;
    });
};

/**
 * Preselect multi select value dynamically
 *
 * @param element
 * @param value
 */
const preselectMultiSelectValue = (element, value) => {
    const items = element.querySelectorAll(SELECT_LIST_ITEM);

    items.forEach((item) => {
        if (item.value === value) {
            item.selected = true;
        }
    });
};

/**
 * Empty the TagList of the multi select element
 *
 * @param element
 */
const emptyMultiSelectValues = (element) => {
    const tagList = element.querySelector(TAG_LIST);
    if (!tagList) return;

    const tagsButtons = Array.from(tagList.querySelectorAll(TAG_REMOVE_BTN));

    tagsButtons.forEach((tagBtn) => {
        tagBtn.click();
    });

    setTimeout(() => {
        element.value = '';
        element.invalid = false;
        const tooltip = getNextElement(element, TOOLTIP);
        if (tooltip) tooltip.remove();
    }, 500);
};

/**
 * Collect multi select values from the tag list located bellow the multi select box
 *
 * @param element
 * @returns {Array}
 */
const getMultiSelectValues = (element) => {
    const tagList = element.querySelector(TAG_LIST);
    const tags = Array.from(tagList.querySelectorAll(TAG));

    let languages = [];

    tags.forEach((tag) => {
        languages.push(tag.value);
    });

    return languages;
};

/**
 * Collect multi select values text from the tag list located bellow the multi select box
 *
 * e.g. if value is en then the text is English
 *
 * @param element
 * @returns {Array}
 */
const getMultiSelectValuesText = (element) => {
    const tagList = element.querySelector(TAG_LIST);
    const tags = Array.from(tagList.querySelectorAll(TAG));

    let languages = [];

    tags.forEach((tag) => {
        const tagLabel = tag.querySelector(TAG_LABEL);
        languages.push(tagLabel.innerText.trim());
    });

    return languages;
};

/**
 * Enable the next button in Step1 of the wizard
 */
const enableNextButtonStep1 = () => {
    const button = step1.querySelector(BUTTON_NEXT);
    button.disabled = selectedFiles.length + selectedDicts.length + selectedTags.length === 0;
};

/**
 * Populates the i18n root dropdown box with the fetched paths from an AEM endpoint
 */
const populateI18nRoot = () => {
    const rootPaths = $(I18N_ROOT_PATHS).get(0);
    $.get(I18N_ROOT_PATHS_SERVLET).done((data) => {
        rootPaths.items.clear();
        data.paths.forEach(value => {
            const item = convertToSelectItem(value.path, value.path);
            rootPaths.items.add(item)
        });
    });

    const i18nChild = document.querySelector(I18N_CHILD);
    i18nChild.classList.add(VISIBILITY_HIDDEN);
};

/**
 * Populates the i18n child selectbox with fetched i18n paths (childs of selected dictionary in the root)
 *
 * @param selectBox instance of a CoralUI selectbox (Coral.Select)
 */
const populateI18nChild = (selectBox) => {
    const childPaths = $(I18N_CHILD_PATHS).get(0);
    const i18nChild = document.querySelector(I18N_CHILD);

    if (selectBox.value) {
        i18nChild.classList.remove(VISIBILITY_HIDDEN);
        const url = `${I18N_CHILD_PATHS_SERVLET}${selectBox.value}`;

        $.get(url).done((data) => {
            childPaths.items.clear();
            data.dicts.forEach(value => childPaths.items.add(convertToSelectItem(value.path, value.lang)));
        });
    } else {
        i18nChild.classList.add(VISIBILITY_HIDDEN);
    }
};

/**
 * Converts input into Json formatted Coral.UI selectbox
 *
 * @param value
 * @param textContent
 * @returns {{value: *, content: {textContent: *}}}
 */
const convertToSelectItem = (value, textContent) => {
    return {
        value: value,
        content: {
            textContent: textContent
        }
    }
};

/**
 * Toggles view in first step of wizard
 *
 * @param selectBox instance of a CoralUI selectbox (Coral.Select)
 */
const toggleWizardView = (selectBox) => {
    const dictView = document.querySelector(I18N_VIEW);
    const filesView = document.querySelector(FILES_VIEW);
    const tagsView = document.querySelector(TAGS_VIEW);
    const includeChildPagesChk = document.querySelector(INCLUDE_CHILD_PAGES_CHK);
    const i18Title = document.querySelector(I18N_TITLE);
    const tagTitle = document.querySelector(TAG_TITLE);
    includeChildPagesChkChange(includeChildPagesChk, selectBox.value);

    if (selectBox.value === FILES) {
        filesView.hidden = false;
        dictView.hidden = true;
    	tagsView.hidden = true;
        includeChildPagesChk.hidden = false;
        i18Title.classList.remove(I18N_TITLE_EXPANDED);
    } else if (selectBox.value === I18N) {
        filesView.hidden = true;
        dictView.hidden = false;
       	tagsView.hidden = true;
        includeChildPagesChk.hidden = true;
        i18Title.classList.add(I18N_TITLE_EXPANDED);
    }else if (selectBox.value === TAGS){
		filesView.hidden = true;
        dictView.hidden = true;
       	tagsView.hidden = false;
        includeChildPagesChk.hidden = false;
        i18Title.classList.remove(I18N_TITLE_EXPANDED);
    }
};